﻿using BepInEx;
using ExitGames.Client.Photon.StructWrapping;
using GorillaNetworking;
using HarmonyLib;
using Photon.Pun;
using Mod.gg.Classes;
using StupidTemplate.Mods;
using StupidTemplate.Notifications;
using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;
using static OVRHaptics;
using static Mod.gg.Menu.Buttons;
using static Mod.gg.Classes.Inputs;
using static Mod.gg.Menu.Config;
using Mod.gg.Mods;
using TMPro;
using Color = UnityEngine.Color;
using System.Collections.Generic;
using System.Runtime.InteropServices.ComTypes;
using System.Reflection;

namespace Mod.gg.Menu
{
    [HarmonyPatch(typeof(GorillaLocomotion.GTPlayer))]
    [HarmonyPatch("LateUpdate", MethodType.Normal)]
    public class Main : MonoBehaviour
    {
        // Constant
        public static bool hasranonce = false;
        public static bool haschangedpage = false;
        public static GameObject COCText = null;
        public static GameObject COCTextupper = null;
        public static GameObject MOTDTEXT = null;
        public static GameObject MOTDTEXTupper = null;
        public static GameObject Wallmon = null;
        private static void SetStumpBoards()
        {
            COCText = GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/COC Text");
            COCTextupper = GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/CodeOfConduct");
            MOTDTEXT = GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/motdtext");
            MOTDTEXTupper = GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/motd (1)");
            Wallmon = GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/ScreenText (1)");
        }
        public static void InitilizeTriggerColorsAndText(Color color)// this is iis
        {
            foreach (GorillaNetworkJoinTrigger v in (List<GorillaNetworkJoinTrigger>)typeof(PhotonNetworkController).GetField("allJoinTriggers", BindingFlags.NonPublic | BindingFlags.Instance).GetValue(PhotonNetworkController.Instance))
            {
                try
                {
                    JoinTriggerUI ui = (JoinTriggerUI)typeof(GorillaNetworkJoinTrigger).GetField("ui", BindingFlags.NonPublic | BindingFlags.Instance).GetValue(v);
                    JoinTriggerUITemplate temp = (JoinTriggerUITemplate)typeof(JoinTriggerUI).GetField("template", BindingFlags.NonPublic | BindingFlags.Instance).GetValue(ui);

                    Material instanceMat = new Material(NewMat);
                    instanceMat.color = color;

                    temp.ScreenBG_AbandonPartyAndSoloJoin = instanceMat;
                    temp.ScreenBG_AlreadyInRoom = instanceMat;
                    temp.ScreenBG_ChangingGameModeSoloJoin = instanceMat;
                    temp.ScreenBG_Error = instanceMat;
                    temp.ScreenBG_InPrivateRoom = instanceMat;
                    temp.ScreenBG_LeaveRoomAndGroupJoin = instanceMat;
                    temp.ScreenBG_LeaveRoomAndSoloJoin = instanceMat;
                    temp.ScreenBG_NotConnectedSoloJoin = instanceMat;
                }
                catch { }
            }
            PhotonNetworkController.Instance.UpdateTriggerScreens();
        }
        public static int[] InstanceIDS =
        {
            137216,
            136048,
            136130,
            137092,
            542490,
            561580,
            663508,
            561352
        };
        public static Material NewMat = new Material(Shader.Find("GorillaTag/UberShader"));
        public static bool AllBoardColorsChanged;
        public static void TryApplyBoardColors()
        {
            if (!AllBoardColorsChanged)
            {
                for (int i = 0; i < InstanceIDS.Length; i++)
                {
                    SetBoardColors(InstanceIDS[i], MenuColor);
                }
            }
        }
        public static string[] MapPaths =
        {
            "Mountain",
            "skyjungle",
            "Canyon/Canyon",
            "Beach",
            "Forest",
            "City_WorkingPrefab",
            "Mountain",
            "TreeRoom",
            "skyjungle"
        };
        public static void SetBoardColors(int instanceID, Color color)
        {
            foreach (string path in MapPaths)
            {
                string fullPath;
                if (!path.Contains("Mountain") && !path.Contains("skyjungle"))
                {
                    fullPath = "Environment Objects/LocalObjects_Prefab/" + path;
                }
                else
                {
                    fullPath = path;
                }
                GameObject parent = GameObject.Find(fullPath);
                if (parent == null)
                {
                    continue;
                }
                for (int i = 0; i < parent.transform.childCount; i++)
                {
                    GameObject child = parent.transform.GetChild(i).gameObject;
                    if (child.GetInstanceID() == instanceID && child.name.Contains("UnityTempFile"))
                    {
                        if (child.TryGetComponent<Renderer>(out Renderer renderer))
                        {
                            if (NewMat == null)
                            {
                                return;
                            }
                            Material matInstance = new Material(NewMat)
                            {
                                color = color
                            };
                            renderer.material = matInstance;
                        }
                        return;
                    }
                }
            }
        }

        public static void Prefix()
        {
            try
            {
                SafteyManager.NoGameQuitTrace();
                SetStumpBoards();
                COCText.GetComponent<TMPro.TextMeshPro>().text = COCMainText;
                COCTextupper.GetComponent<TMPro.TextMeshPro>().text = COCTitle;
                MOTDTEXT.GetComponent<TMPro.TextMeshPro>().text = MOTDMainText;
                MOTDTEXTupper.GetComponent<TMPro.TextMeshPro>().text = MOTDTitle;
                Wallmon.GetComponent<TMPro.TextMeshPro>().text = WALLMONTitle + "\n" + WALLMONMainText;
                if (!AllBoardColorsChanged)
                {
                    TryApplyBoardColors();
                    InitilizeTriggerColorsAndText(MenuColor);
                    AllBoardColorsChanged = true;
                }
                if (KeyboardKey(Key.H) && KeyboardKey(Key.Q))
                {
                    pageNumber = 0;
                    Global.ReturnHome();
                    RecreateMenu();
                }
                if (KeyboardKey(Key.L) && KeyboardKey(Key.Q))
                {
                    PhotonNetwork.Disconnect();
                }
                if (!hasranonce)
                {
                    if (ButtonOnLaunch != "")
                    {
                        GetIndex(ButtonOnLaunch).enabled = true;
                        hasranonce = true;
                    }
                }
                bool toOpen = (!RightHanded && ControllerInputPoller.instance.leftControllerSecondaryButton) || (RightHanded && ControllerInputPoller.instance.rightControllerSecondaryButton);
                bool keyboardOpen = UnityInput.Current.GetKey(keyboardButton);
                if (menu == null)
                {
                    if (toOpen || keyboardOpen)
                    {
                        CreateMenu();
                        RecenterMenu(RightHanded, keyboardOpen);
                        if (reference == null)
                        {
                            CreateReference(RightHanded);
                        }
                    }
                }
                else
                {
                    if ((toOpen || keyboardOpen))
                    {
                        RecenterMenu(RightHanded, keyboardOpen);
                    }
                    else
                    {
                        GameObject.Find("Shoulder Camera").transform.Find("CM vcam1").gameObject.SetActive(true);

                        Rigidbody comp = menu.AddComponent(typeof(Rigidbody)) as Rigidbody;
                        if (RightHanded)
                        {
                            comp.velocity = GorillaLocomotion.GTPlayer.Instance.rightHandCenterVelocityTracker.GetAverageVelocity(true, 0);
                            comp.useGravity = false;
                        }
                        else
                        {
                            comp.velocity = GorillaLocomotion.GTPlayer.Instance.leftHandCenterVelocityTracker.GetAverageVelocity(true, 0);
                            comp.useGravity = false;
                        }

                        UnityEngine.Object.Destroy(menu, 1);
                        menu = null;

                        UnityEngine.Object.Destroy(reference);
                        reference = null;
                    }
                }
                Mod.gg.Notifications.NotifiLibMODS.SendNotification();
            }
            catch (Exception exc)
            {
                UnityEngine.Debug.LogError(string.Format("{0} // Error initializing at {1}: {2}", PluginInfo.Name, exc.StackTrace, exc.Message));
            }
            try
            {
                if (fpsObject != null)
                {
                    fpsObject.text = "FPS: " + Mathf.Ceil(1f / Time.unscaledDeltaTime).ToString();
                }
                foreach (ButtonInfo[] buttonlist in buttons)
                {
                    foreach (ButtonInfo v in buttonlist)
                    {
                        if (v.enabled)
                        {
                            if (v.method != null)
                            {
                                try
                                {
                                    v.method.Invoke();
                                }
                                catch (Exception exc)
                                {
                                    UnityEngine.Debug.LogError(string.Format("{0} // Error with mod {1} at {2}: {3}", PluginInfo.Name, v.buttonText, exc.StackTrace, exc.Message));
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception exc)
            {
                UnityEngine.Debug.LogError(string.Format("{0} // Error with executing mods at {1}: {2}", PluginInfo.Name, exc.StackTrace, exc.Message));
            }
        }
        public static Vector3 pos;
        public static Vector3 MenuPosition(PositionType positionType)
        {
            if (positionType == PositionType.AboveLeft)
            {
                pos = new Vector3(0.56f, 0.30f, 0.45f);
            }
            if (positionType == PositionType.AboveRight)
            {
                pos = new Vector3(0.56f, -0.30f, 0.45f);
            }
            if (positionType == PositionType.TopLeft)
            {
                pos = new Vector3(0.56f, 0.30f, 0.35f);
            }
            if (positionType == PositionType.TopRight)
            {
                pos = new Vector3(0.56f, -0.30f, 0.35f);
            }
            if (positionType == PositionType.BottomLeft)
            {
                pos = new Vector3(0.56f, 0.33f, -0.385f);
            }
            if (positionType == PositionType.BottomRight)
            {
                pos = new Vector3(0.56f, -0.18f, -0.33f);
            }
            if (positionType == PositionType.CenterLeft)
            {
                pos = new Vector3(0.56f, -0.30f, 0);
            }
            if (positionType == PositionType.Center)
            {
                pos = new Vector3(0.56f, 0f, 0);
            }
            if (positionType == PositionType.CenterRight)
            {
                pos = new Vector3(0.56f, -0.30f, 0);
            }
            Vector3 position = pos;
            return position;
        }
        // Functions
        public static void CreateMenu()
        {
            // Menu Holder
            menu = GameObject.CreatePrimitive(PrimitiveType.Cube);
            UnityEngine.Object.Destroy(menu.GetComponent<Rigidbody>());
            UnityEngine.Object.Destroy(menu.GetComponent<BoxCollider>());
            UnityEngine.Object.Destroy(menu.GetComponent<Renderer>());
            menu.transform.localScale = new Vector3(0.1f, 0.3f, 0.3825f);

            // Menu Background
            menuBackground = GameObject.CreatePrimitive(PrimitiveType.Cube);
            UnityEngine.Object.Destroy(menuBackground.GetComponent<Rigidbody>());
            UnityEngine.Object.Destroy(menuBackground.GetComponent<BoxCollider>());
            menuBackground.transform.parent = menu.transform;
            menuBackground.transform.rotation = Quaternion.identity;
            menuBackground.transform.localScale = menuSize;
            menuBackground.GetComponent<Renderer>().material.color = MenuColor;
            menuBackground.transform.position = new Vector3(0.055f, 0f, 0f);
            RoundedManager.Round(menuBackground);
            RoundedManager.MakeOutline(menuBackground);

            // Canvas
            canvasObject = new GameObject();
            canvasObject.transform.parent = menu.transform;
            Canvas canvas = canvasObject.AddComponent<Canvas>();
            CanvasScaler canvasScaler = canvasObject.AddComponent<CanvasScaler>();
            canvasObject.AddComponent<GraphicRaycaster>();
            canvas.renderMode = RenderMode.WorldSpace;
            canvasScaler.dynamicPixelsPerUnit = 1000f;

            Text Text = new GameObject
            {
                transform =
                    {
                        parent = canvasObject.transform
                    }
            }.AddComponent<Text>();
            Text.text = MenuName;
            Text.font = currentFont;
            Text.fontSize = 1; Text.color = TextColor;
            Text.alignment = TextAnchor.MiddleCenter;
            Text.fontStyle = FontStyle.Bold;
            Text.resizeTextForBestFit = true;
            Text.resizeTextMinSize = 0;
            Text.fontSize = (int)0.15f;
            RectTransform recttt = Text.GetComponent<RectTransform>();
            recttt.localPosition = Vector3.zero;
            recttt.sizeDelta = new Vector2(0.06f, 0.04f);
            recttt.localPosition = new Vector3(0.059f, 0f, 0.155f);
            recttt.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
            // Disconnect
            if (DisconnectButtonEnabled)
            {
                GameObject disconnectButton = GameObject.CreatePrimitive(PrimitiveType.Cube);
                if (!UnityInput.Current.GetKey(KeyCode.Q))
                {
                    disconnectButton.layer = 2;
                }
                UnityEngine.Object.Destroy(disconnectButton.GetComponent<Rigidbody>());
                disconnectButton.GetComponent<BoxCollider>().isTrigger = true;
                disconnectButton.transform.parent = menu.transform;
                disconnectButton.transform.rotation = Quaternion.identity;
                disconnectButton.transform.localScale = new Vector3(0.01f, 0.19f, 0.14f);
                disconnectButton.transform.localPosition = new Vector3(0.56f, 0.33f, -0.385f);
                disconnectButton.GetComponent<Renderer>().material.color = DisconectButtonColor;
                disconnectButton.AddComponent<Classes.Button>().relatedText = "Disconnect";
                RoundedManager.Round(disconnectButton);
                Text disconnectText = new GameObject
                {
                    transform =
                    {
                        parent = canvasObject.transform
                    }
                }.AddComponent<Text>();
                disconnectText.text = DisconnectTect;
                disconnectText.font = currentFont;
                disconnectText.fontSize = 1;
                disconnectText.color = TextColor;
                disconnectText.alignment = TextAnchor.MiddleCenter;
                disconnectText.fontStyle = FontStyle.Bold;
                disconnectText.resizeTextForBestFit = true;
                disconnectText.resizeTextMinSize = 0;
                disconnectText.fontSize = (int)0.15f;
                RectTransform disconnectRect = disconnectText.GetComponent<RectTransform>();
                disconnectRect.localPosition = Vector3.zero;
                disconnectRect.sizeDelta = new Vector2(0.05f, 0.015f);
                disconnectRect.localPosition = new Vector3(0.059f, 0.0975f, -0.145f);
                disconnectRect.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
                RoundedManager.MakeOutline(disconnectButton);
            }
            if (pagebuttons)
            {
                GameObject homeButton = GameObject.CreatePrimitive(PrimitiveType.Cube);
                if (!UnityInput.Current.GetKey(KeyCode.Q))
                {
                    homeButton.layer = 2;
                }
                UnityEngine.Object.Destroy(homeButton.GetComponent<Rigidbody>());
                homeButton.GetComponent<BoxCollider>().isTrigger = true;
                homeButton.transform.parent = menu.transform;
                homeButton.transform.rotation = Quaternion.identity;
                homeButton.transform.localScale = new Vector3(0.01f, 0.19f, 0.14f);
                homeButton.transform.localPosition = new Vector3(0.56f, -0.33f, -0.385f);
                homeButton.GetComponent<Renderer>().material.color = HomeButtonColor;
                homeButton.AddComponent<Classes.Button>().relatedText = "NextPage";
                RoundedManager.Round(homeButton);
                Text homeText = new GameObject
                {
                    transform =
                    {
                        parent = canvasObject.transform
                    }
                }.AddComponent<Text>();
                homeText.text = NextText;
                homeText.font = currentFont;
                homeText.fontSize = 1; homeText.color = TextColor;
                homeText.alignment = TextAnchor.MiddleCenter;
                homeText.fontStyle = FontStyle.Bold;
                homeText.resizeTextForBestFit = true;
                homeText.resizeTextMinSize = 0;
                homeText.fontSize = (int)0.15f;
                RectTransform rectt = homeText.GetComponent<RectTransform>();
                rectt.localPosition = Vector3.zero;
                rectt.sizeDelta = new Vector2(0.05f, 0.02f);
                rectt.localPosition = new Vector3(0.059f, -0.0975f, -0.145f);
                rectt.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
                RoundedManager.MakeOutline(homeButton);

                GameObject disconnectButton = GameObject.CreatePrimitive(PrimitiveType.Cube);
                if (!UnityInput.Current.GetKey(KeyCode.Q))
                {
                    disconnectButton.layer = 2;
                }
                UnityEngine.Object.Destroy(disconnectButton.GetComponent<Rigidbody>());
                disconnectButton.GetComponent<BoxCollider>().isTrigger = true;
                disconnectButton.transform.parent = menu.transform;
                disconnectButton.transform.rotation = Quaternion.identity;
                disconnectButton.transform.localScale = new Vector3(0.01f, 0.19f, 0.14f);
                disconnectButton.transform.localPosition = new Vector3(0.56f, -0.119f, -0.385f);
                disconnectButton.GetComponent<Renderer>().material.color = DisconectButtonColor;
                disconnectButton.AddComponent<Classes.Button>().relatedText = "LastPage";
                RoundedManager.Round(disconnectButton);
                Text disconnectText = new GameObject
                {
                    transform =
                    {
                        parent = canvasObject.transform
                    }
                }.AddComponent<Text>();
                disconnectText.text = LastText;
                disconnectText.font = currentFont;
                disconnectText.fontSize = 1;
                disconnectText.color = TextColor;
                disconnectText.alignment = TextAnchor.MiddleCenter;
                disconnectText.fontStyle = FontStyle.Bold;
                disconnectText.resizeTextForBestFit = true;
                disconnectText.resizeTextMinSize = 0;
                disconnectText.fontSize = (int)0.15f;
                RectTransform disconnectRect = disconnectText.GetComponent<RectTransform>();
                disconnectRect.localPosition = Vector3.zero;
                disconnectRect.sizeDelta = new Vector2(0.05f, 0.02f);
                disconnectRect.localPosition = new Vector3(0.059f, -0.0365f, -0.145f);
                disconnectRect.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
                RoundedManager.MakeOutline(disconnectButton);
            }
            if (HomeButtonEnabled)
            {
                GameObject homeButton = GameObject.CreatePrimitive(PrimitiveType.Cube);
                if (!UnityInput.Current.GetKey(KeyCode.Q))
                {
                    homeButton.layer = 2;
                }
                UnityEngine.Object.Destroy(homeButton.GetComponent<Rigidbody>());
                homeButton.GetComponent<BoxCollider>().isTrigger = true;
                homeButton.transform.parent = menu.transform;
                homeButton.transform.rotation = Quaternion.identity;
                homeButton.transform.localScale = new Vector3(0.01f, 0.19f, 0.14f);
                homeButton.transform.localPosition = new Vector3(0.56f, 0.119f, -0.385f);
                homeButton.GetComponent<Renderer>().material.color = HomeButtonColor;
                homeButton.AddComponent<Classes.Button>().relatedText = "Home";
                RoundedManager.Round(homeButton);
                Text homeText = new GameObject
                {
                    transform =
                    {
                        parent = canvasObject.transform
                    }
                }.AddComponent<Text>();
                homeText.text = HomeText;
                homeText.font = currentFont;
                homeText.fontSize = 1; homeText.color = TextColor;
                homeText.alignment = TextAnchor.MiddleCenter;
                homeText.fontStyle = FontStyle.Bold;
                homeText.resizeTextForBestFit = true;
                homeText.resizeTextMinSize = 0;
                homeText.fontSize = (int)0.15f;
                RectTransform rectt = homeText.GetComponent<RectTransform>();
                rectt.localPosition = Vector3.zero;
                rectt.sizeDelta = new Vector2(0.05f, 0.015f);
                rectt.localPosition = new Vector3(0.059f, 0.0365f, -0.145f);
                rectt.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
                RoundedManager.MakeOutline(homeButton);
                // Mod Buttons
                ButtonInfo[] activeButtons = buttons[buttonsType].Skip(pageNumber * buttonsPerPage).Take(buttonsPerPage).ToArray();
                for (int i = 0; i < activeButtons.Length; i++)
                {
                    CreateButton(i * 0.089f, activeButtons[i]);
                }
            }
        }
        private static void SetButtonColor(GameObject buttonObject, ButtonInfo method)
        {
            Renderer renderer = buttonObject.GetComponent<Renderer>();
            renderer.material.color = method.enabled ? Config.MenuButtonEnabledColor : Config.MenuButtonColor;
        }
        public static void CreateButton(float offset, ButtonInfo method)
        {
            GameObject buttonObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
            if (!UnityInput.Current.GetKey(KeyCode.Q))
            {
                buttonObject.layer = 2;
            }
            UnityEngine.Object.Destroy(buttonObject.GetComponent<Rigidbody>());
            buttonObject.GetComponent<BoxCollider>().isTrigger = true;
            buttonObject.transform.parent = menu.transform;
            buttonObject.transform.rotation = Quaternion.identity;
            buttonObject.transform.localScale = new Vector3(0.01f, 0.85f, 0.08f);
            buttonObject.transform.localPosition = new Vector3(0.56f, 0f, 0.31f - offset);
            buttonObject.AddComponent<Classes.Button>().relatedText = method.buttonText;
            SetButtonColor(buttonObject, method);
            RoundedManager.Round(buttonObject);
            Text buttonText = new GameObject
            {
                transform =
                {
                    parent = canvasObject.transform
                }
            }.AddComponent<Text>();
            buttonText.font = currentFont;
            buttonText.text = method.overlapText ?? method.buttonText;
            buttonText.supportRichText = true;
            buttonText.fontSize = 1;
            buttonText.color = method.enabled ? TextColorEnabled : TextColor;
            buttonText.alignment = TextAnchor.MiddleCenter;
            buttonText.fontStyle = FontStyle.Bold;
            buttonText.resizeTextForBestFit = true;
            buttonText.resizeTextMinSize = 0;
            buttonText.fontSize = (int)0.15f;
            RectTransform textRect = buttonText.GetComponent<RectTransform>();
            textRect.localPosition = Vector3.zero;
            textRect.sizeDelta = new Vector2(0.1f, 0.02f);
            textRect.localPosition = new Vector3(.058f, 0, .119f - offset / 2.6f);
            textRect.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
        }

        public static void RecreateMenu()
        {
            if (menu != null)
            {
                UnityEngine.Object.Destroy(menu);
                menu = null;

                CreateMenu();
                RecenterMenu(RightHanded, UnityInput.Current.GetKey(keyboardButton));
            }
        }
        public static Transform RightHand = GorillaTagger.Instance.offlineVRRig.GetComponent<VRRig>().rightHand.rigTarget;
        public static Transform LeftHand = GorillaTagger.Instance.offlineVRRig.GetComponent<VRRig>().leftHand.rigTarget;
        public static bool IsHolding = false;
        public static GameObject grabobj = GameObject.CreatePrimitive(PrimitiveType.Cube);
        public static void RecenterMenu(bool isRightHanded, bool isKeyboardCondition)
        {
            if (!isKeyboardCondition)
            {
                if (!isRightHanded)
                {
                    menu.transform.position = GorillaTagger.Instance.leftHandTransform.position;
                    menu.transform.rotation = GorillaTagger.Instance.leftHandTransform.rotation;
                }
                else
                {
                    menu.transform.position = GorillaTagger.Instance.rightHandTransform.position;
                    Vector3 rotation = GorillaTagger.Instance.rightHandTransform.rotation.eulerAngles;
                    rotation += new Vector3(0f, 0f, 180f);
                    menu.transform.rotation = Quaternion.Euler(rotation);
                }
            }
            else
            {
                try
                {
                    TPC = GameObject.Find("Player Objects/Third Person Camera/Shoulder Camera").GetComponent<Camera>();
                }
                catch { }

                GameObject.Find("Shoulder Camera").transform.Find("CM vcam1").gameObject.SetActive(false);

                if (TPC != null)
                {
                    TPC.transform.position = Camera.main.transform.position;
                    TPC.transform.rotation = Quaternion.Euler(0, Camera.main.transform.eulerAngles.y, 0);
                    menu.transform.parent = TPC.transform;
                    menu.transform.position = (TPC.transform.position + (Vector3.Scale(TPC.transform.forward, new Vector3(0.5f, 0.5f, 0.5f)))) + (Vector3.Scale(TPC.transform.up, new Vector3(-0.02f, -0.02f, -0.02f)));
                    Vector3 rot = TPC.transform.rotation.eulerAngles;
                    rot = new Vector3(rot.x - 90, rot.y + 90, rot.z);
                    menu.transform.rotation = Quaternion.Euler(rot);

                    if (reference != null)
                    {
                        if (Mouse.current.leftButton.isPressed)
                        {
                            RaycastHit hit;
                            if (Physics.Raycast(TPC.ScreenPointToRay(Mouse.current.position.ReadValue()), out hit, 100))
                            {
                                Classes.Button collide = hit.transform.gameObject.GetComponent<Classes.Button>();
                                if (collide != null)
                                {
                                    collide.OnTriggerEnter(buttonCollider);
                                }
                            }
                        }
                        else
                        {
                            reference.transform.position = new Vector3(999f, -999f, -999f);
                        }
                    }
                }
            }
        }

        public static void CreateReference(bool isRightHanded)
        {
            reference = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            if (isRightHanded)
            {
                reference.transform.parent = GorillaTagger.Instance.leftHandTransform;
            }
            else
            {
                reference.transform.parent = GorillaTagger.Instance.rightHandTransform;
            }
            reference.GetComponent<Renderer>().material.color = ButtonColliderColor;
            reference.transform.localPosition = new Vector3(0f, -0.1f, 0f);
            reference.transform.localScale = new Vector3(0.01f, 0.01f, 0.01f);
            buttonCollider = reference.GetComponent<SphereCollider>();
        }

        public static void Toggle(string buttonText)
        {
            int lastPage = ((buttons[buttonsType].Length + buttonsPerPage - 1) / buttonsPerPage) - 1;
            if (buttonText == "Disconnect")
            {
                PhotonNetwork.Disconnect();
            }
            if (buttonText == "Home")
            {
                pageNumber = 0;
                Global.ReturnHome();
                RecreateMenu();
            }
            foreach (MainCategory category in Enum.GetValues(typeof(MainCategory)))
            {
                if (GetIndex(buttonText).MainButtonCatagory == category)
                {
                    CatagoryManager.OpenCatagory(category);
                }
            }
            if (buttonText == "LastPage")
            {
                pageNumber--;
                if (pageNumber < 0)
                {
                    pageNumber = lastPage;
                }
            }
            else
            {
                if (buttonText == "NextPage")
                {
                    pageNumber++;
                    if (pageNumber > lastPage)
                    {
                        pageNumber = 0;
                    }
                }
                else
                {
                    ButtonInfo target = GetIndex(buttonText);
                    if (target != null)
                    {
                        if (target.isTogglable)
                        {
                            target.enabled = !target.enabled;
                            if (target.enabled)
                            {
                                NotifiLib.SendNotification(target.toolTip);
                                if (target.enableMethod != null)
                                {
                                    try { target.enableMethod.Invoke(); } catch { }
                                }
                            }
                            else
                            {
                                NotifiLib.SendNotification(target.toolTip);
                                if (target.disableMethod != null)
                                {
                                    try { target.disableMethod.Invoke(); } catch { }
                                }
                            }
                        }
                        else
                        {
                            NotifiLib.SendNotification(target.toolTip);
                            if (target.method != null)
                            {
                                try { target.method.Invoke(); } catch { }
                            }
                        }
                    }
                    else
                    {

                    }
                }
            }
            RecreateMenu();
        }

        public static GradientColorKey[] GetSolidGradient(UnityEngine.Color color)
        {
            return new GradientColorKey[] { new GradientColorKey(color, 0f), new GradientColorKey(color, 1f) };
        }

        public static ButtonInfo GetIndex(string buttonText)
        {
            foreach (ButtonInfo[] buttons in Menu.Buttons.buttons)
            {
                foreach (ButtonInfo button in buttons)
                {
                    if (button.buttonText == buttonText)
                    {
                        return button;
                    }
                }
            }

            return null;
        }

        // Variables
        // Important
        // Objects
        public static GameObject menu;
        public static GameObject menuBackground;
        public static GameObject reference;
        public static GameObject canvasObject;

        public static SphereCollider buttonCollider;
        public static Camera TPC;
        public static Text fpsObject;

        // Data
        public static int pageNumber = 0;
        public static int buttonsType = 0;
    }
}
