﻿using Mod.gg.Classes;
using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using static Mod.gg.Menu.Main;

namespace Mod.gg.Menu
{
    public class Config
    {
        public enum PositionType
        {
            AboveLeft,
            AboveRight,
            TopLeft,
            TopRight,
            CenterLeft,
            CenterRight,
            Center,
            BottomLeft,
            BottomRight,
            BottomCenter
        }
        public enum Category
        {
            Null,
            Main,
            Settings,
            Safety,
            Movement,
            Visual,
            Player,
            Room,
            //ect...
        }
        public enum MainCategory
        {
            Null,
            Settings,
            Safety,
            Movement,
            Visual,
            Player,
            Room,
            //ect...
        }
        // color configs
        public static Color OutlineColor = new Color32(45, 45, 45, 255);
        public static Color MenuColor = new Color32(18, 18, 18, 255);
        public static Color MenuButtonColor = new Color32(45, 45, 45, 255);
        public static Color MenuButtonEnabledColor = new Color32(60, 70, 180, 255);
        public static Color DisconectButtonColor = new Color32(18, 18, 18, 255);
        public static Color PageButtonColors = new Color32(45, 45, 45, 255);
        public static Color HomeButtonColor = new Color32(18, 18, 18, 255);
        public static Color ButtonColliderColor = new Color32(45, 45, 45, 255);
        public static Color TextColor = Color.white;
        public static Color TextColorEnabled = Color.white;
        // string configs
        public static string MenuName = "Mod.gg Template";
        public static string HomeText = "Home";
        public static string DisconnectTect = "Leave";
        public static string NextText = ">";
        public static string LastText = "<";
        // menu vars
        public static Vector3 menuSize = new Vector3(0.01f, 0.9f, 0.95f); // Depth, Width, Height
        public static int buttonsPerPage = 7;
        public static Font currentFont = (Resources.GetBuiltinResource(typeof(Font), "Arial.ttf") as Font);
        public static KeyCode keyboardButton = KeyCode.Q;
        //mwnu comps
        public static bool fpsCounterEnabled = true;
        public static bool DisconnectButtonEnabled = true;
        public static bool RightHanded = false;
        public static bool BarkmenuVarient = true;
        public static bool disableNotifications = false;
        public static bool HasOutline = true;
        public static bool HomeButtonEnabled = true;
        public static bool pagebuttons = true;
        // button on launch
        public static string ButtonOnLaunch = "";
        // COC | MOTD | WALLMON
        public static string COCTitle = "•MOD.GG-TEMPLATE•" + "\n-----------------------------";
        public static string COCMainText = "\n HI, THANK YOU FOR DOWNLOADING MY TEMPLATE YOU CAN CHANGE THIS TEXT WHENEVER YOU WANT IN (CONFIG)";
        public static string MOTDTitle = "•WARNING•" + "\n------------------------------";
        public static string MOTDMainText = "\nTHIS PROJECT/MENU TEMPLATE MAY OR MAY NOT BREAK GTAG TOS SO ANY BANS ARE NOT THE MENU CREATOR'S AND OR THE DEVS FAULT";
        public static string WALLMONTitle = "WARNING" + "\n--------------------";
        public static string WALLMONMainText = "BE CAREFULL THERE ARE DEVS/ADMIN/MODS IN THESE SERVERS";
    }
}
