﻿using Photon.Pun;
using Mod.gg.Classes;
using Mod.gg.Mods;
using System;
using static Mod.gg.Menu.Config;

namespace Mod.gg.Menu
{
    internal class Buttons
    {
        public static ButtonInfo CreateButton(string BtnText,Category BtnCategory, Action method = null, Action enableMethod = null, Action disableMethod = null, bool isTogglable = false, bool enabled = false, string toolTip = "")
        {
            return new ButtonInfo
            {
                buttonText = BtnText,
                ButtonCategory = BtnCategory,
                method = method,
                enableMethod = enableMethod,
                disableMethod = disableMethod,
                isTogglable = isTogglable,
                enabled = enabled,
                toolTip = toolTip
            };
        }
        public static ButtonInfo CreateMainButton(string BtnText, Category BtnCategory, MainCategory MainBtnCat,bool isTogglable = false, bool enabled = false, string toolTip = "")
        {
            return new ButtonInfo
            {
                buttonText = BtnText,
                ButtonCategory = BtnCategory,
                MainButtonCatagory = MainBtnCat,
                isTogglable = isTogglable,
                enabled = enabled,
                toolTip = toolTip
            };
        }
        public static ButtonInfo[][] buttons = new ButtonInfo[][]
        {
            new ButtonInfo[] { // Main / home
                CreateMainButton("Settings", Category.Main, MainCategory.Settings, isTogglable: false, toolTip: "Opens the settings page."),
                CreateMainButton("Saftey", Category.Main, MainCategory.Safety, isTogglable: false, toolTip: "Opens the Saftey page."),
                CreateMainButton("Movement", Category.Main, MainCategory.Movement, isTogglable: false, toolTip: "Opens the Movement page."),
                CreateMainButton("Visual", Category.Main, MainCategory.Visual, isTogglable: false, toolTip: "Opens the Visual page."),
                CreateMainButton("Player", Category.Main, MainCategory.Player, isTogglable: false, toolTip: "Opens the Player page."),
                CreateMainButton("Room", Category.Main, MainCategory.Room, isTogglable: false, toolTip: "Opens the Room page."),
            },

            new ButtonInfo[] { // Settings
                CreateButton("Menu", Category.Settings,() => SettingsMods.MenuSettings(), isTogglable: false, toolTip: "Opens the settings for the menu."),
                CreateButton("MovementSettings", Category.Settings, () => SettingsMods.MovementSettings(), isTogglable: false, toolTip: "Opens the movement settings for the menu."),
            },

            new ButtonInfo[] { // Menu Settings
                CreateButton("Return to Settings", Category.Settings, () => SettingsMods.EnterSettings(), isTogglable: false, toolTip: "Returns to the main settings page for the menu."),
                CreateButton("Right Hand",Category.Settings,enableMethod: () => SettingsMods.RightHand(), disableMethod: () => SettingsMods.LeftHand(), toolTip: "Puts the menu on your right hand."),
                CreateButton("Notifications", Category.Settings,enableMethod: () => SettingsMods.EnableNotifications(), disableMethod: () => SettingsMods.DisableNotifications(), enabled: !disableNotifications, toolTip: "Toggles the notifications."),
                CreateButton("FPS Counter", Category.Settings, enableMethod: () => SettingsMods.EnableFPSCounter(), disableMethod: () => SettingsMods.DisableFPSCounter(), enabled: fpsCounterEnabled, toolTip: "Toggles the FPS counter."),
                CreateButton("Disconnect Button", Category.Settings, enableMethod: () => SettingsMods.EnableDisconnectButton(), disableMethod: () => SettingsMods.DisableDisconnectButton(), enabled: DisconnectButtonEnabled, toolTip: "Toggles the disconnect button."),

            },

            new ButtonInfo[] { // Movement Settings
                CreateButton("Return to Settings", Category.Settings, () => SettingsMods.EnterSettings(), isTogglable: false, toolTip: "Returns to the main settings page for the menu."),
            },

            new ButtonInfo[] { // room Settings
                CreateButton("Return to Settings", Category.Settings, () => SettingsMods.MenuSettings(), isTogglable: false, toolTip: "Opens the settings for the menu.")
            },
            new ButtonInfo[] { // Saftey Mods
                CreateButton("PlaceHolder", Category.Safety, isTogglable: false, toolTip: "PlaceHolder"),
                CreateButton("PlaceHolder", Category.Safety, isTogglable: false, toolTip: "PlaceHolder"),
                CreateButton("PlaceHolder", Category.Safety, isTogglable: false, toolTip: "PlaceHolder"),
                CreateButton("PlaceHolder", Category.Safety, isTogglable: false, toolTip: "PlaceHolder"),
                CreateButton("PlaceHolder", Category.Safety, isTogglable: false, toolTip: "PlaceHolder"),
                CreateButton("PlaceHolder", Category.Safety, isTogglable: false, toolTip: "PlaceHolder"),
                CreateButton("PlaceHolder", Category.Safety, isTogglable: false, toolTip: "PlaceHolder"),
            },
            new ButtonInfo[] { // Movement Mods
                CreateButton("PlaceHolder", Category.Movement, isTogglable: false, toolTip: "PlaceHolder"),
                CreateButton("PlaceHolder", Category.Movement, isTogglable: false, toolTip: "PlaceHolder"),
                CreateButton("PlaceHolder", Category.Movement, isTogglable: false, toolTip: "PlaceHolder"),
                CreateButton("PlaceHolder", Category.Movement, isTogglable: false, toolTip: "PlaceHolder"),
                CreateButton("PlaceHolder", Category.Movement, isTogglable: false, toolTip: "PlaceHolder"),
                CreateButton("PlaceHolder", Category.Movement, isTogglable: false, toolTip: "PlaceHolder"),
                CreateButton("PlaceHolder", Category.Movement, isTogglable: false, toolTip: "PlaceHolder"),
            },
            new ButtonInfo[] { // Visual Mods
                CreateButton("PlaceHolder", Category.Visual, isTogglable: false, toolTip: "PlaceHolder"),
                CreateButton("PlaceHolder", Category.Visual, isTogglable: false, toolTip: "PlaceHolder"),
                CreateButton("PlaceHolder", Category.Visual, isTogglable: false, toolTip: "PlaceHolder"),
                CreateButton("PlaceHolder", Category.Visual, isTogglable: false, toolTip: "PlaceHolder"),
                CreateButton("PlaceHolder", Category.Visual, isTogglable: false, toolTip: "PlaceHolder"),
                CreateButton("PlaceHolder", Category.Visual, isTogglable: false, toolTip: "PlaceHolder"),
                CreateButton("PlaceHolder", Category.Visual, isTogglable: false, toolTip: "PlaceHolder"),
                CreateButton("GunLibTest",Category.Visual,()=> Gunlib.UpdateGun(delegate{ },false), isTogglable: true, toolTip: "Just to see what the gunlib looks like"),
                CreateButton("GunLibTest(GunLock)",Category.Visual,()=> Gunlib.UpdateGun(delegate{ },true), isTogglable: true, toolTip: "to test the vrrig gunlock system in the gunlib"),
            },
            new ButtonInfo[] { // Player Mods
                CreateButton("PlaceHolder", Category.Player, isTogglable: false, toolTip: "PlaceHolder"),
                CreateButton("PlaceHolder", Category.Player, isTogglable: false, toolTip: "PlaceHolder"),
                CreateButton("PlaceHolder", Category.Player, isTogglable: false, toolTip: "PlaceHolder"),
                CreateButton("PlaceHolder", Category.Player, isTogglable: false, toolTip: "PlaceHolder"),
                CreateButton("PlaceHolder", Category.Player, isTogglable: false, toolTip: "PlaceHolder"),
                CreateButton("PlaceHolder", Category.Player, isTogglable: false, toolTip: "PlaceHolder"),
                CreateButton("PlaceHolder", Category.Player, isTogglable: false, toolTip: "PlaceHolder"),
            },
            new ButtonInfo[] { // Room Mods
                CreateButton("PlaceHolder", Category.Room, isTogglable: false, toolTip: "PlaceHolder"),
                CreateButton("PlaceHolder", Category.Room, isTogglable: false, toolTip: "PlaceHolder"),
                CreateButton("PlaceHolder", Category.Room, isTogglable: false, toolTip: "PlaceHolder"),
                CreateButton("PlaceHolder", Category.Room, isTogglable: false, toolTip: "PlaceHolder"),
                CreateButton("PlaceHolder", Category.Room, isTogglable: false, toolTip: "PlaceHolder"),
                CreateButton("PlaceHolder", Category.Room, isTogglable: false, toolTip: "PlaceHolder"),
                CreateButton("PlaceHolder", Category.Room, isTogglable: false, toolTip: "PlaceHolder"),
            },
        };
    }
}
