﻿using BepInEx;
using CSCore;
using Photon.Pun;
using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace Mod.gg.Menu
{
    [BepInPlugin("another.axiom.gorilla.tag", "PreformanceStats", "0.0.1")]
    class PreformanceStats : BaseUnityPlugin
    {
        public static Texture2D Texture;
        private void Start()
        {
            Texture = CreateRoundedTexture(300, 35, Mod.gg.Menu.Config.MenuColor, 10);
        }
        private void OnGUI()
        {
            PreformanceStatsGUI();
        }
        // one line wonder lol
        private void PreformanceStatsGUI() { var r = new Rect(20, 20, 300, 35); if (Texture != null) GUI.DrawTexture(r, Texture); else GUI.Box(r, GUIContent.none); GUI.color = Color.white; var s = new GUIStyle(GUI.skin.label) { alignment = TextAnchor.MiddleCenter, fontSize = 12, fontStyle = FontStyle.Bold }; GUI.Label(r, $"FPS: {Mathf.RoundToInt(1f / Time.unscaledDeltaTime)}   Ping: {PhotonNetwork.GetPing()}ms   Latency: {PhotonNetwork.GetPing() / 2}ms", s); }
        private Texture2D CreateRoundedTexture(int w, int h, Color f, int r)
        {
            var t = new Texture2D(w, h);
            var p = new Color32[w * h];
            for (int y = 0; y < h; y++)
            {
                for (int x = 0; x < w; x++)
                {
                    bool b = true;
                    if (x < r && y < r && Vector2.Distance(new Vector2(r, r), new Vector2(x, y)) > r) b = false;
                    if (x > w - r && y < r && Vector2.Distance(new Vector2(w - r, r), new Vector2(x, y)) > r) b = false;
                    if (x < r && y > h - r && Vector2.Distance(new Vector2(r, h - r), new Vector2(x, y)) > r) b = false;
                    if (x > w - r && y > h - r && Vector2.Distance(new Vector2(w - r, h - r), new Vector2(x, y)) > r) b = false;
                    p[y * w + x] = b ? f : new Color(0, 0, 0, 0);
                }
            }
            t.SetPixels32(p);
            t.Apply();
            return t;
        }
    }
}
