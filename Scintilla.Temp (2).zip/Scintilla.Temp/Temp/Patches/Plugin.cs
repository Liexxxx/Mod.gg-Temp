﻿using BepInEx;
using System.ComponentModel;

namespace Mod.gg.Patches
{
    [Description(Mod.gg.PluginInfo.Description)]
    [BepInPlugin(Mod.gg.PluginInfo.GUID, Mod.gg.PluginInfo.Name, Mod.gg.PluginInfo.Version)]
    public class HarmonyPatches : BaseUnityPlugin
    {
        private void OnEnable()
        {
            Menu.ApplyHarmonyPatches();
        }

        private void OnDisable()
        {
            Menu.RemoveHarmonyPatches();
        }
    }
}
