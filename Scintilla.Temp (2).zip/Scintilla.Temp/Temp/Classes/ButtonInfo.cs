﻿using System;
using static Mod.gg.Menu.Config;

namespace Mod.gg.Classes
{
    public class ButtonInfo
    {
        public string buttonText = "-";
        public string overlapText = null;
        public Action method = null;
        public Action enableMethod = null;
        public Action disableMethod = null;
        public bool enabled = false;
        public bool isTogglable = true;
        public string toolTip = "This button doesn't have a tooltip/tutorial.";
        public Category ButtonCategory = Category.Null;
        public MainCategory MainButtonCatagory = MainCategory.Null;
    }
}
