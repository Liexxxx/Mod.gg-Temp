﻿using Mod.gg.Menu;
using Mod.gg.Patches;
using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace Mod.gg.Classes
{
    class RoundedManager
    {
        public static void Round(GameObject obj)
        {
            obj.GetComponent<Renderer>().enabled = false;
            float bevel = 0.02f;

            Renderer ToRoundRenderer = obj.GetComponent<Renderer>();


            GameObject BaseA = GameObject.CreatePrimitive(PrimitiveType.Cube);
            BaseA.GetComponent<Renderer>().enabled = true;
            UnityEngine.Object.Destroy(BaseA.GetComponent<Collider>());
            BaseA.transform.parent = obj.transform.parent;
            BaseA.transform.rotation = Quaternion.identity;
            BaseA.transform.localPosition = obj.transform.localPosition;
            BaseA.transform.localScale = obj.transform.localScale + new Vector3(0f, bevel * -2.55f, 0f);

            GameObject BaseB = GameObject.CreatePrimitive(PrimitiveType.Cube);
            BaseB.GetComponent<Renderer>().enabled = true;
            UnityEngine.Object.Destroy(BaseB.GetComponent<Collider>());
            BaseB.transform.parent = obj.transform.parent;
            BaseB.transform.rotation = Quaternion.identity;
            BaseB.transform.localPosition = obj.transform.localPosition;
            BaseB.transform.localScale = obj.transform.localScale + new Vector3(0f, 0f, -bevel * 2f);

            GameObject RoundCornerA = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            RoundCornerA.GetComponent<Renderer>().enabled = true;
            UnityEngine.Object.Destroy(RoundCornerA.GetComponent<Collider>());
            RoundCornerA.transform.parent = obj.transform.parent;
            RoundCornerA.transform.rotation = Quaternion.Euler(0f, 0f, 90f);
            RoundCornerA.transform.localPosition = obj.transform.localPosition + new Vector3(0f, (obj.transform.localScale.y / 2f) - (bevel * 1.275f), (obj.transform.localScale.z / 2f) - bevel);
            RoundCornerA.transform.localScale = new Vector3(bevel * 2.55f, obj.transform.localScale.x / 2f, bevel * 2f);

            GameObject RoundCornerB = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            RoundCornerB.GetComponent<Renderer>().enabled = true;
            UnityEngine.Object.Destroy(RoundCornerB.GetComponent<Collider>());
            RoundCornerB.transform.parent = obj.transform.parent;
            RoundCornerB.transform.rotation = Quaternion.Euler(0f, 0f, 90f);
            RoundCornerB.transform.localPosition = obj.transform.localPosition + new Vector3(0f, -(obj.transform.localScale.y / 2f) + (bevel * 1.275f), (obj.transform.localScale.z / 2f) - bevel);
            RoundCornerB.transform.localScale = new Vector3(bevel * 2.55f, obj.transform.localScale.x / 2f, bevel * 2f);

            GameObject RoundCornerC = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            RoundCornerC.GetComponent<Renderer>().enabled = true;
            UnityEngine.Object.Destroy(RoundCornerC.GetComponent<Collider>());
            RoundCornerC.transform.parent = obj.transform.parent;
            RoundCornerC.transform.rotation = Quaternion.Euler(0f, 0f, 90f);
            RoundCornerC.transform.localPosition = obj.transform.localPosition + new Vector3(0f, (obj.transform.localScale.y / 2f) - (bevel * 1.275f), -(obj.transform.localScale.z / 2f) + bevel);
            RoundCornerC.transform.localScale = new Vector3(bevel * 2.55f, obj.transform.localScale.x / 2f, bevel * 2f);

            GameObject RoundCornerD = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            RoundCornerD.GetComponent<Renderer>().enabled = true;
            UnityEngine.Object.Destroy(RoundCornerD.GetComponent<Collider>());
            RoundCornerD.transform.parent = obj.transform.parent;
            RoundCornerD.transform.rotation = Quaternion.Euler(0f, 0f, 90f);
            RoundCornerD.transform.localPosition = obj.transform.localPosition + new Vector3(0f, -(obj.transform.localScale.y / 2f) + (bevel * 1.275f), -(obj.transform.localScale.z / 2f) + bevel);
            RoundCornerD.transform.localScale = new Vector3(bevel * 2.55f, obj.transform.localScale.x / 2f, bevel * 2f);

            GameObject[] ToChange = new GameObject[]
            {
    BaseA,
    BaseB,
    RoundCornerA,
    RoundCornerB,
    RoundCornerC,
    RoundCornerD
            };

            foreach (GameObject objs in ToChange)
            {
                objs.GetComponent<Renderer>().material.color = obj.GetComponent<Renderer>().material.color;
            }
        }
        public static void MakeOutline(GameObject obj)
        {
            float outlineThickness = 0.01f;

            GameObject outline = GameObject.CreatePrimitive(PrimitiveType.Cube);
            UnityEngine.Object.Destroy(outline.GetComponent<Collider>());

            outline.transform.SetParent(obj.transform.parent);
            outline.transform.localPosition = obj.transform.localPosition;
            outline.transform.localRotation = obj.transform.localRotation;
            outline.transform.localScale = obj.transform.localScale + new Vector3(0, outlineThickness, outlineThickness) - new Vector3(0.001f,0,0);

            Renderer outlineRenderer = outline.GetComponent<Renderer>();
            outlineRenderer.enabled = true;
            outlineRenderer.material.color = Config.OutlineColor;

            Round(outline);
        }
    }
}
