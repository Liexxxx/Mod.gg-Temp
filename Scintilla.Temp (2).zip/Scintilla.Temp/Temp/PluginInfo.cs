﻿namespace Mod.gg
{
    internal class PluginInfo
    {
        public const string GUID = "org.gorillatag.mods";
        public const string Name = "Mod.gg Template";
        public const string Description = "Menu open to the public";
        public const string Version = "1.0.2";
    }
}
