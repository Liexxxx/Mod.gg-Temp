﻿using static Mod.gg.Menu.Main;
using static Mod.gg.Menu.Config;

namespace Mod.gg.Mods
{
    internal class SettingsMods
    {
        public static void EnterSettings()
        {
            buttonsType = 1;
        }

        public static void MenuSettings()
        {
            buttonsType = 2;
        }

        public static void MovementSettings()
        {
            buttonsType = 3;
        }

        public static void ProjectileSettings()
        {
            buttonsType = 4;
        }

        public static void RightHand()
        {
            RightHanded = true;
        }

        public static void LeftHand()
        {
            RightHanded = false;
        }

        public static void EnableFPSCounter()
        {
            fpsCounterEnabled = true;
        }

        public static void DisableFPSCounter()
        {
            fpsCounterEnabled = false;
        }

        public static void EnableNotifications()
        {
            DisconnectButtonEnabled = false;
        }

        public static void DisableNotifications()
        {
            disableNotifications = true;
        }

        public static void EnableDisconnectButton()
        {
            DisconnectButtonEnabled = true;
        }

        public static void DisableDisconnectButton()
        {
            DisconnectButtonEnabled = false;
        }
    }
}
