﻿using BepInEx;
using ExitGames.Client.Photon.StructWrapping;
using GorillaNetworking;
using HarmonyLib;
using Photon.Pun;
using Mod.gg.Classes;
using StupidTemplate.Mods;
using StupidTemplate.Notifications;
using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;
using static OVRHaptics;
using static Mod.gg.Menu.Buttons;
using static Mod.gg.Classes.Inputs;
using static Mod.gg.Menu.Config;

namespace Mod.gg.Menu
{
    [HarmonyPatch(typeof(GorillaLocomotion.GTPlayer))]
    [HarmonyPatch("LateUpdate", MethodType.Normal)]
    public class Main : MonoBehaviour
    {
        // Constant
        public static bool hashit;
        public static bool hasranonce = false;
        public static void Prefix()
        {
            try
            {
                if (!hasranonce)
                {
                    if (ButtonOnLaunch != "")
                    {
                        GetIndex(ButtonOnLaunch).enabled = true;
                        hasranonce = true;
                    }
                }
                bool toOpen = (!RightHanded && ControllerInputPoller.instance.leftControllerSecondaryButton) || (RightHanded && ControllerInputPoller.instance.rightControllerSecondaryButton);
                bool keyboardOpen = UnityInput.Current.GetKey(keyboardButton);
                if (menu == null)
                {
                    if (toOpen || keyboardOpen)
                    {
                        CreateMenu();
                        RecenterMenu(RightHanded, keyboardOpen, false);
                        if (reference == null)
                        {
                            CreateReference(RightHanded);
                        }
                    }
                    if (Vector3.Distance(GorillaLocomotion.GTPlayer.Instance.bodyCollider.transform.position - new Vector3(0f,0.09f,1f), GorillaTagger.Instance.offlineVRRig.rightHandTransform.position) < 0.09f && Vector3.Distance(GorillaLocomotion.GTPlayer.Instance.bodyCollider.transform.position - new Vector3(0f, 0.09f, 1f), GorillaTagger.Instance.offlineVRRig.leftHandTransform.position) < 0.09f)
                    {
                        float lastTapTime = 0f;
                        int tapCount = 0;
                        float tapResetTime = 0.25f;
                        if (Time.time - lastTapTime < 0.1f) return;
                        lastTapTime = Time.time;
                        tapCount++;
                        if (tapCount >= 2)
                        {
                            tapCount = 0;
                            hashit = true;
                        }
                    }
                }
                else
                {
                    if ((toOpen || keyboardOpen))
                    {
                        RecenterMenu(RightHanded, keyboardOpen, false);
                    }
                    else
                    {
                        GameObject.Find("Shoulder Camera").transform.Find("CM vcam1").gameObject.SetActive(true);

                        Rigidbody comp = menu.AddComponent(typeof(Rigidbody)) as Rigidbody;
                        if (RightHanded)
                        {
                            comp.velocity = GorillaLocomotion.GTPlayer.Instance.rightHandCenterVelocityTracker.GetAverageVelocity(true, 0);
                            comp.useGravity = false;
                        }
                        else
                        {
                            comp.velocity = GorillaLocomotion.GTPlayer.Instance.leftHandCenterVelocityTracker.GetAverageVelocity(true, 0);
                            comp.useGravity = false;
                        }

                        UnityEngine.Object.Destroy(menu, 1);
                        menu = null;

                        UnityEngine.Object.Destroy(reference);
                        reference = null;
                    }
                }
            }
            catch (Exception exc)
            {
                UnityEngine.Debug.LogError(string.Format("{0} // Error initializing at {1}: {2}", PluginInfo.Name, exc.StackTrace, exc.Message));
            }

            // Constant
            try
            {
                // Pre-Execution
                if (fpsObject != null)
                {
                    fpsObject.text = "FPS: " + Mathf.Ceil(1f / Time.unscaledDeltaTime).ToString();
                }

                // Execute Enabled mods
                foreach (ButtonInfo[] buttonlist in buttons)
                {
                    foreach (ButtonInfo v in buttonlist)
                    {
                        if (v.enabled)
                        {
                            if (v.method != null)
                            {
                                try
                                {
                                    v.method.Invoke();
                                }
                                catch (Exception exc)
                                {
                                    UnityEngine.Debug.LogError(string.Format("{0} // Error with mod {1} at {2}: {3}", PluginInfo.Name, v.buttonText, exc.StackTrace, exc.Message));
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception exc)
            {
                UnityEngine.Debug.LogError(string.Format("{0} // Error with executing mods at {1}: {2}", PluginInfo.Name, exc.StackTrace, exc.Message));
            }
        }
        public static Vector3 pos;
        public static Vector3 MenuPosition(PositionType positionType)
        {
            if (positionType == PositionType.AboveLeft)
            {
                pos = new Vector3(0.56f, 0.30f, 0.45f);
            }
            if (positionType == PositionType.AboveRight)
            {
                pos = new Vector3(0.56f, -0.30f, 0.45f);
            }
            if (positionType == PositionType.TopLeft)
            {
                pos = new Vector3(0.56f, 0.30f, 0.35f);
            }
            if (positionType == PositionType.TopRight)
            {
                pos = new Vector3(0.56f, -0.30f, 0.35f);
            }
            if (positionType == PositionType.BottomLeft)
            {
                pos = new Vector3(0.56f, 0.18f, -0.33f);
            }
            if (positionType == PositionType.BottomRight)
            {
                pos = new Vector3(0.56f, -0.18f, -0.33f);
            }
            if (positionType == PositionType.CenterLeft)
            {
                pos = new Vector3(0.56f, -0.30f, 0);
            }
            if (positionType == PositionType.Center)
            {
                pos = new Vector3(0.56f, 0f, 0);
            }
            if (positionType == PositionType.CenterRight)
            {
                pos = new Vector3(0.56f, -0.30f, 0);
            }
            Vector3 position = pos;
            return position;
        }
        // Functions
        public static void CreateMenu()
        {
            // Menu Holder
            menu = GameObject.CreatePrimitive(PrimitiveType.Cube);
            UnityEngine.Object.Destroy(menu.GetComponent<Rigidbody>());
            UnityEngine.Object.Destroy(menu.GetComponent<BoxCollider>());
            UnityEngine.Object.Destroy(menu.GetComponent<Renderer>());
            menu.transform.localScale = new Vector3(0.1f, 0.3f, 0.3825f);

            // Menu Background
            menuBackground = GameObject.CreatePrimitive(PrimitiveType.Cube);
            UnityEngine.Object.Destroy(menuBackground.GetComponent<Rigidbody>());
            UnityEngine.Object.Destroy(menuBackground.GetComponent<BoxCollider>());
            menuBackground.transform.parent = menu.transform;
            menuBackground.transform.rotation = Quaternion.identity;
            menuBackground.transform.localScale = menuSize;
            menuBackground.GetComponent<Renderer>().material.color = MenuColor;
            menuBackground.transform.position = new Vector3(0.05f, 0f, 0f);
            RoundedMesh.MakeRounded(menuBackground);
            RoundedMesh.makeoutline(menuBackground);


            // Canvas
            canvasObject = new GameObject();
            canvasObject.transform.parent = menu.transform;
            Canvas canvas = canvasObject.AddComponent<Canvas>();
            CanvasScaler canvasScaler = canvasObject.AddComponent<CanvasScaler>();
            canvasObject.AddComponent<GraphicRaycaster>();
            canvas.renderMode = RenderMode.WorldSpace;
            canvasScaler.dynamicPixelsPerUnit = 1000f;

            // Title and FPS
            Text text = new GameObject
            {
                transform =
                    {
                        parent = canvasObject.transform
                    }
            }.AddComponent<Text>();
            text.text = PluginInfo.Version;
            text.font = currentFont;
            text.fontSize = 1;
            text.color = TextColor;
            text.supportRichText = true;
            text.fontStyle = FontStyle.Italic;
            text.alignment = TextAnchor.MiddleCenter;
            text.resizeTextForBestFit = true;
            text.resizeTextMinSize = 0;
            RectTransform component = text.GetComponent<RectTransform>();
            component.localPosition = Vector3.zero;
            component.sizeDelta = new Vector2(0.28f, 0.05f);
            component.position = new Vector3(-0.06f, 0f, -0.11f);
            component.rotation = Quaternion.Euler(new Vector3(360f, 90f, 90f));

            if (fpsCounterEnabled)
            {
                fpsObject = new GameObject
                {
                    transform =
                    {
                        parent = canvasObject.transform
                    }
                }.AddComponent<Text>();
                fpsObject.font = currentFont;
                fpsObject.text = "FPS: " + Mathf.Ceil(1f / Time.unscaledDeltaTime).ToString();
                fpsObject.color = TextColor;
                fpsObject.fontSize = 1;
                fpsObject.supportRichText = true;
                fpsObject.fontStyle = FontStyle.Italic;
                fpsObject.alignment = TextAnchor.MiddleCenter;
                fpsObject.horizontalOverflow = UnityEngine.HorizontalWrapMode.Overflow;
                fpsObject.resizeTextForBestFit = true;
                fpsObject.resizeTextMinSize = 0;
                RectTransform component2 = fpsObject.GetComponent<RectTransform>();
                component2.localPosition = Vector3.zero;
                component2.sizeDelta = new Vector2(0.28f, 0.02f);
                component2.position = new Vector3(0.01f, 0f, 0.135f);
                component2.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
            }

            // Buttons
            // Disconnect
            if (DisconnectButtonEnabled)
            {
                GameObject disconnectbutton = GameObject.CreatePrimitive(PrimitiveType.Cube);
                if (!UnityInput.Current.GetKey(KeyCode.Q))
                {
                    disconnectbutton.layer = 2;
                }
                UnityEngine.Object.Destroy(disconnectbutton.GetComponent<Rigidbody>());
                disconnectbutton.GetComponent<BoxCollider>().isTrigger = true;
                disconnectbutton.transform.parent = menu.transform;
                disconnectbutton.transform.rotation = Quaternion.identity;
                disconnectbutton.transform.localScale = new Vector3(0.09f, 0.35f, 0.08f);
                disconnectbutton.transform.localPosition = MenuPosition(DisconnectPos);
                disconnectbutton.GetComponent<Renderer>().material.color = DisconectButtonColor;
                disconnectbutton.AddComponent<Classes.Button>().relatedText = "Disconnect";
                RoundedMesh.MakeRoundedButtonsBottom(disconnectbutton);
                RoundedMesh.makeoutlinebuttonbottom(disconnectbutton);

                Text discontext = new GameObject
                {
                    transform =
                            {
                                parent = canvasObject.transform
                            }
                }.AddComponent<Text>();
                discontext.text = DisconnectTect;
                discontext.font = currentFont;
                discontext.fontSize = 1;
                discontext.color = TextColor;
                discontext.alignment = TextAnchor.MiddleCenter;
                discontext.fontStyle = FontStyle.Normal;
                discontext.resizeTextForBestFit = true;
                discontext.resizeTextMinSize = 0;
                discontext.fontSize = (int)0.15f;

                RectTransform rectt = discontext.GetComponent<RectTransform>();
                rectt.localPosition = Vector3.zero;
                rectt.sizeDelta = new Vector2(0.15f, 0.025f);
                rectt.localPosition = new Vector3(0.064f, 0.055f, -0.127f);
                rectt.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
            }

            // Page Buttons
            GameObject gameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
            if (!UnityInput.Current.GetKey(KeyCode.Q))
            {
                gameObject.layer = 2;
            }
            UnityEngine.Object.Destroy(gameObject.GetComponent<Rigidbody>());
            gameObject.GetComponent<BoxCollider>().isTrigger = true;
            gameObject.transform.parent = menu.transform;
            gameObject.transform.rotation = Quaternion.identity;
            gameObject.transform.localScale = new Vector3(0.09f, 0.14f, 0.08f);
            gameObject.transform.localPosition = MenuPosition(PrevPagePos);
            gameObject.GetComponent<Renderer>().material.color = PageButtonColors;
            gameObject.AddComponent<Classes.Button>().relatedText = "PreviousPage";
            RoundedMesh.MakeRoundedButtons(gameObject);
            RoundedMesh.makeoutlinebutton(gameObject);

            text = new GameObject
            {
                transform =
                        {
                            parent = canvasObject.transform
                        }
            }.AddComponent<Text>();
            text.font = currentFont;
            text.text = "<";
            text.fontSize = 1;
            text.color = TextColor;
            text.alignment = TextAnchor.MiddleCenter;
            text.resizeTextForBestFit = true;
            text.resizeTextMinSize = 0;
            component = text.GetComponent<RectTransform>();
            component.localPosition = Vector3.zero;
            component.sizeDelta = new Vector2(0.2f, 0.03f);
            component.localPosition = new Vector3(0.56f, 0.3f, -0.35f);
            component.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));

            gameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
            if (!UnityInput.Current.GetKey(KeyCode.Q))
            {
                gameObject.layer = 2;
            }
            UnityEngine.Object.Destroy(gameObject.GetComponent<Rigidbody>());
            gameObject.GetComponent<BoxCollider>().isTrigger = true;
            gameObject.transform.parent = menu.transform;
            gameObject.transform.rotation = Quaternion.identity;
            gameObject.transform.localScale = new Vector3(0.09f, 0.14f, 0.08f);
            gameObject.transform.localPosition = MenuPosition(NextPagePos);
            gameObject.GetComponent<Renderer>().material.color = PageButtonColors;
            gameObject.AddComponent<Classes.Button>().relatedText = "NextPage";
            RoundedMesh.MakeRoundedButtons(gameObject);
            RoundedMesh.makeoutlinebutton(gameObject);
            if (HomeButtonEnabled)
            {
                GameObject HomeButton = GameObject.CreatePrimitive(PrimitiveType.Cube);
                if (!UnityInput.Current.GetKey(KeyCode.Q))
                {
                    HomeButton.layer = 2;
                }
                UnityEngine.Object.Destroy(HomeButton.GetComponent<Rigidbody>());
                HomeButton.GetComponent<BoxCollider>().isTrigger = true;
                HomeButton.transform.parent = menu.transform;
                HomeButton.transform.rotation = Quaternion.identity;
                HomeButton.transform.localScale = new Vector3(0.09f, 0.35f, 0.08f);
                HomeButton.transform.localPosition = MenuPosition(HomePos);
                HomeButton.GetComponent<Renderer>().material.color = HomeButtonColor;
                HomeButton.AddComponent<Classes.Button>().relatedText = "Home";
                RoundedMesh.MakeRoundedButtonsBottom(HomeButton);
                RoundedMesh.makeoutlinebuttonbottom(HomeButton);

                Text hometext = new GameObject
                {
                    transform =
                            {
                                parent = canvasObject.transform
                            }
                }.AddComponent<Text>();
                hometext.text = HomeText;
                hometext.font = currentFont;
                hometext.fontSize = 1;
                hometext.color = TextColor;
                hometext.alignment = TextAnchor.MiddleCenter;
                hometext.fontStyle = FontStyle.Normal;
                hometext.resizeTextForBestFit = true;
                hometext.resizeTextMinSize = 0;
                hometext.fontSize = (int)0.15f;

                RectTransform rectt = hometext.GetComponent<RectTransform>();
                rectt.localPosition = Vector3.zero;
                rectt.sizeDelta = new Vector2(0.15f, 0.025f);
                rectt.localPosition = new Vector3(0.064f, -0.055f, -0.127f);
                rectt.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
                // Mod Buttons
                ButtonInfo[] activeButtons = buttons[buttonsType].Skip(pageNumber * buttonsPerPage).Take(buttonsPerPage).ToArray();
                for (int i = 0; i < activeButtons.Length; i++)
                {
                    CreateButton(i * 0.1f, activeButtons[i]);
                }
            }
        }

        public static void CreateButton(float offset, ButtonInfo method)
        {
            GameObject gameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
            if (!UnityInput.Current.GetKey(KeyCode.Q))
            {
                gameObject.layer = 2;
            }
            UnityEngine.Object.Destroy(gameObject.GetComponent<Rigidbody>());
            gameObject.GetComponent<BoxCollider>().isTrigger = true;
            gameObject.transform.parent = menu.transform;
            gameObject.transform.rotation = Quaternion.identity;
            gameObject.transform.localScale = new Vector3(0.09f, 0.7f, 0.08f);
            gameObject.transform.localPosition = new Vector3(0.56f, 0f, 0.28f - offset);
            gameObject.AddComponent<Classes.Button>().relatedText = method.buttonText;
            RoundedMesh.MakeRoundedButtons(gameObject);
            RoundedMesh.makeoutlinebutton(gameObject);
            ColorChanger colorChanger = gameObject.AddComponent<ColorChanger>();
            if (method.enabled)
            {
                gameObject.GetComponent<Renderer>().material.color = new Color32(50, 50, 50, 255);
            }
            else
            {
                gameObject.GetComponent<Renderer>().material.color = new Color32(100, 100, 100, 255);
            }
            colorChanger.Start();
            Text text = new GameObject
            {
                transform =
        {
            parent = canvasObject.transform
        }
            }.AddComponent<Text>();
            text.font = currentFont;
            text.text = method.buttonText;
            if (method.overlapText != null)
            {
                text.text = method.overlapText;
            }
            text.supportRichText = true;
            text.fontSize = 1;
            if (method.enabled)
            {
                text.color = TextColorEnabled;
            }
            else
            {
                text.color = TextColor;
            }
            text.alignment = TextAnchor.MiddleCenter;
            text.fontStyle = FontStyle.Normal;
            text.resizeTextForBestFit = true;
            text.resizeTextMinSize = 0;
            text.fontSize = (int)0.15f;
            RectTransform component = text.GetComponent<RectTransform>();
            component.localPosition = Vector3.zero;
            component.sizeDelta = new Vector2(0.15f, 0.025f);
            component.localPosition = new Vector3(.064f, 0, .111f - offset / 2.6f);
            component.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
        }

        public static void RecreateMenu()
        {
            if (menu != null)
            {
                UnityEngine.Object.Destroy(menu);
                menu = null;

                CreateMenu();
                RecenterMenu(RightHanded, UnityInput.Current.GetKey(keyboardButton),BarkmenuVarient);
            }
        }
        public static Transform RightHand = GorillaTagger.Instance.offlineVRRig.GetComponent<VRRig>().rightHand.rigTarget;
        public static Transform LeftHand = GorillaTagger.Instance.offlineVRRig.GetComponent<VRRig>().leftHand.rigTarget;
        public static bool IsHolding = false;
        public static GameObject grabobj = GameObject.CreatePrimitive(PrimitiveType.Cube);
        public static void RecenterMenu(bool isRightHanded, bool isKeyboardCondition, bool isbarkmenu)
        {
            if (!isKeyboardCondition)
            {
                if (!isRightHanded)
                {
                    menu.transform.position = GorillaTagger.Instance.leftHandTransform.position;
                    menu.transform.rotation = GorillaTagger.Instance.leftHandTransform.rotation;
                }
                else
                {
                    menu.transform.position = GorillaTagger.Instance.rightHandTransform.position;
                    Vector3 rotation = GorillaTagger.Instance.rightHandTransform.rotation.eulerAngles;
                    rotation += new Vector3(0f, 0f, 180f);
                    menu.transform.rotation = Quaternion.Euler(rotation);
                }
            }
            else
            {
                try
                {
                    TPC = GameObject.Find("Player Objects/Third Person Camera/Shoulder Camera").GetComponent<Camera>();
                }
                catch { }

                GameObject.Find("Shoulder Camera").transform.Find("CM vcam1").gameObject.SetActive(false);

                if (TPC != null)
                {
                    TPC.transform.position = Camera.main.transform.position;
                    TPC.transform.rotation = Quaternion.AngleAxis(Camera.main.transform.rotation.x, GorillaTagger.Instance.headCollider.center);
                    menu.transform.parent = TPC.transform;
                    menu.transform.position = (TPC.transform.position + (Vector3.Scale(TPC.transform.forward, new Vector3(0.5f, 0.5f, 0.5f)))) + (Vector3.Scale(TPC.transform.up, new Vector3(-0.02f, -0.02f, -0.02f)));
                    Vector3 rot = TPC.transform.rotation.eulerAngles;
                    rot = new Vector3(rot.x - 90, rot.y + 90, rot.z);
                    menu.transform.rotation = Quaternion.Euler(rot);

                    if (reference != null)
                    {
                        if (Mouse.current.leftButton.isPressed)
                        {
                            RaycastHit hit;
                            if (Physics.Raycast(TPC.ScreenPointToRay(Mouse.current.position.ReadValue()), out hit, 100))
                            {
                                Classes.Button collide = hit.transform.gameObject.GetComponent<Classes.Button>();
                                if (collide != null)
                                {
                                    collide.OnTriggerEnter(buttonCollider);
                                }
                            }
                        }
                        else
                        {
                            reference.transform.position = new Vector3(999f, -999f, -999f);
                        }
                    }
                }
            }
        }

        public static void CreateReference(bool isRightHanded)
        {
            reference = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            if (isRightHanded)
            {
                reference.transform.parent = GorillaTagger.Instance.leftHandTransform;
            }
            else
            {
                reference.transform.parent = GorillaTagger.Instance.rightHandTransform;
            }
            reference.GetComponent<Renderer>().material.color = ButtonColliderColor;
            reference.transform.localPosition = new Vector3(0f, -0.1f, 0f);
            reference.transform.localScale = new Vector3(0.01f, 0.01f, 0.01f);
            buttonCollider = reference.GetComponent<SphereCollider>();
        }

        public static void Toggle(string buttonText)
        {
            int lastPage = ((buttons[buttonsType].Length + buttonsPerPage - 1) / buttonsPerPage) - 1;
            if (buttonText == "Disconnect")
            {
                PhotonNetwork.Disconnect();
            }
            if (buttonText == "Home")
            {
                pageNumber = 0;
                Global.ReturnHome();
            }
            if (buttonText == "PreviousPage")
            {
                pageNumber--;
                if (pageNumber < 0)
                {
                    pageNumber = lastPage;
                }
            }
            else
            {
                if (buttonText == "NextPage")
                {
                    pageNumber++;
                    if (pageNumber > lastPage)
                    {
                        pageNumber = 0;
                    }
                }
                else
                {
                    ButtonInfo target = GetIndex(buttonText);
                    if (target != null)
                    {
                        if (target.isTogglable)
                        {
                            target.enabled = !target.enabled;
                            if (target.enabled)
                            {
                                NotifiLib.SendNotification("<color=grey>[</color><color=green>ENABLE</color><color=grey>]</color> " + target.toolTip);
                                if (target.enableMethod != null)
                                {
                                    try { target.enableMethod.Invoke(); } catch { }
                                }
                            }
                            else
                            {
                                NotifiLib.SendNotification("<color=grey>[</color><color=red>DISABLE</color><color=grey>]</color> " + target.toolTip);
                                if (target.disableMethod != null)
                                {
                                    try { target.disableMethod.Invoke(); } catch { }
                                }
                            }
                        }
                        else
                        {
                            NotifiLib.SendNotification("<color=grey>[</color><color=green>ENABLE</color><color=grey>]</color> " + target.toolTip);
                            if (target.method != null)
                            {
                                try { target.method.Invoke(); } catch { }
                            }
                        }
                    }
                    else
                    {
                        UnityEngine.Debug.LogError(buttonText + " does not exist");
                    }
                }
            }
            RecreateMenu();
        }

        public static GradientColorKey[] GetSolidGradient(UnityEngine.Color color)
        {
            return new GradientColorKey[] { new GradientColorKey(color, 0f), new GradientColorKey(color, 1f) };
        }

        public static ButtonInfo GetIndex(string buttonText)
        {
            foreach (ButtonInfo[] buttons in Menu.Buttons.buttons)
            {
                foreach (ButtonInfo button in buttons)
                {
                    if (button.buttonText == buttonText)
                    {
                        return button;
                    }
                }
            }

            return null;
        }

        // Variables
        // Important
        // Objects
        public static GameObject menu;
        public static GameObject menuBackground;
        public static GameObject reference;
        public static GameObject canvasObject;

        public static SphereCollider buttonCollider;
        public static Camera TPC;
        public static Text fpsObject;

        // Data
        public static int pageNumber = 0;
        public static int buttonsType = 0;
    }
}
