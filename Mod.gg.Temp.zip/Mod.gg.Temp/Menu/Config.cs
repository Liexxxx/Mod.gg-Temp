﻿using Mod.gg.Classes;
using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using static Mod.gg.Menu.Main;

namespace Mod.gg.Menu
{
    public class Config
    {
        public enum PositionType
        {
            AboveLeft,
            AboveRight,
            TopLeft,
            TopRight,
            CenterLeft,
            CenterRight,
            Center,
            BottomLeft,
            BottomRight,
            BottomCenter
        }
        // color configs
        public static Color OutlineColor = Color.white;
        public static Color MenuColor = new Color32(30, 30, 30, 255);
        public static Color MenuButtonColor = new Color32(100, 100, 100, 255);
        public static Color MenuButtonEnabledColor = new Color32(50, 50, 50, 255);
        public static Color DisconectButtonColor = new Color32(100, 100, 100, 255);
        public static Color PageButtonColors = new Color32(100, 100, 100, 255);
        public static Color HomeButtonColor = new Color32(100, 100, 100, 255);
        public static Color ButtonColliderColor = new Color32(30, 30, 30, 255);
        public static Color TextColor = Color.white;
        public static Color TextColorEnabled = Color.white;
        // string configs
        public static string HomeText = "Home";
        public static string DisconnectTect = "Leave";
        // menu vars
        public static Vector3 menuSize = new Vector3(0.1f, 0.8f, 0.8f); // Depth, Width, Height
        public static int buttonsPerPage = 6;
        public static Font currentFont = (Resources.GetBuiltinResource(typeof(Font), "Arial.ttf") as Font);
        public static KeyCode keyboardButton = KeyCode.Q;
        //mwnu comps
        public static bool fpsCounterEnabled = true;
        public static bool DisconnectButtonEnabled = true;
        public static bool RightHanded = false;
        public static bool BarkmenuVarient = true;
        public static bool disableNotifications = false;
        public static bool HasOutline = true;
        public static bool HomeButtonEnabled = true;
        // postion configs
        public static PositionType PrevPagePos = PositionType.AboveLeft;
        public static PositionType NextPagePos = PositionType.AboveRight;
        public static PositionType DisconnectPos = PositionType.BottomLeft;
        public static PositionType HomePos = PositionType.BottomRight;
        // button on launch
        public static string ButtonOnLaunch = "";
        
    }
}
