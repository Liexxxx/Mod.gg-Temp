﻿using Photon.Pun;
using Mod.gg.Classes;
using Mod.gg.Mods;
using System;
using static Mod.gg.Menu.Config;

namespace Mod.gg.Menu
{
    internal class Buttons
    {
        public static ButtonInfo CreateButton(string buttonText, Action method = null, Action enableMethod = null, Action disableMethod = null, bool isTogglable = false, bool enabled = false, string toolTip = "")
        {
            return new ButtonInfo
            {
                buttonText = buttonText,
                method = method,
                enableMethod = enableMethod,
                disableMethod = disableMethod,
                isTogglable = isTogglable,
                enabled = enabled,
                toolTip = toolTip
            };
        }
        public static ButtonInfo[][] buttons = new ButtonInfo[][]
        {
            new ButtonInfo[] { // Main / home
                CreateButton("Settings", () => SettingsMods.EnterSettings(), isTogglable: false, toolTip: "Opens the settings page."),
                CreateButton("PlaceHolder", isTogglable: false),
                CreateButton("ToggablePlaceHolder", isTogglable: true),
                CreateButton("PlaceHolder2", isTogglable: false),
                CreateButton("ToggablePlaceHolder2", isTogglable: true),
                CreateButton("PlaceHolder3", isTogglable: false),
                CreateButton("ToggablePlaceHolder3", isTogglable: true),
                CreateButton("PlaceHolder4", isTogglable: false),
                CreateButton("ToggablePlaceHolder4", isTogglable: true),
                CreateButton("PlaceHolder5", isTogglable: false),
                CreateButton("ToggablePlaceHolder5", isTogglable: true),
                CreateButton("PlaceHolder6", isTogglable: false),
                CreateButton("ToggablePlaceHolder6", isTogglable: true),
                CreateButton("PlaceHolder7", isTogglable: false),
                CreateButton("ToggablePlaceHolder7", isTogglable: true),
            },

            new ButtonInfo[] { // Settings
                CreateButton("Menu", () => SettingsMods.MenuSettings(), isTogglable: false, toolTip: "Opens the settings for the menu."),
                CreateButton("Movement", () => SettingsMods.MovementSettings(), isTogglable: false, toolTip: "Opens the movement settings for the menu."),
            },

            new ButtonInfo[] { // Menu Settings
                CreateButton("Return to Settings", () => SettingsMods.EnterSettings(), isTogglable: false, toolTip: "Returns to the main settings page for the menu."),
                CreateButton("Right Hand", enableMethod: () => SettingsMods.RightHand(), disableMethod: () => SettingsMods.LeftHand(), toolTip: "Puts the menu on your right hand."),
                CreateButton("Notifications", enableMethod: () => SettingsMods.EnableNotifications(), disableMethod: () => SettingsMods.DisableNotifications(), enabled: !disableNotifications, toolTip: "Toggles the notifications."),
                CreateButton("FPS Counter", enableMethod: () => SettingsMods.EnableFPSCounter(), disableMethod: () => SettingsMods.DisableFPSCounter(), enabled: fpsCounterEnabled, toolTip: "Toggles the FPS counter."),
                CreateButton("Disconnect Button", enableMethod: () => SettingsMods.EnableDisconnectButton(), disableMethod: () => SettingsMods.DisableDisconnectButton(), enabled: DisconnectButtonEnabled, toolTip: "Toggles the disconnect button."),

            },

            new ButtonInfo[] { // Movement Settings
                CreateButton("Return to Settings", () => SettingsMods.EnterSettings(), isTogglable: false, toolTip: "Returns to the main settings page for the menu."),
            },

            new ButtonInfo[] { // room Settings
                CreateButton("Return to Settings", () => SettingsMods.MenuSettings(), isTogglable: false, toolTip: "Opens the settings for the menu.")
            },
        };
    }
}
