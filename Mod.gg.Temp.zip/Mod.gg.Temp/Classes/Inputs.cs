﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.InputSystem;
using static System.Runtime.CompilerServices.RuntimeHelpers;

namespace Mod.gg.Classes
{
    internal class Inputs
    {
        public static bool RightGrip()
        {
            if (ControllerInputPoller.instance.rightControllerGripFloat > 0.5f)
            {
                return ControllerInputPoller.instance.rightControllerGripFloat > 0.5f;
            }
            return false;
        }
        public static bool LeftGrip()
        {
            if (ControllerInputPoller.instance.leftControllerGripFloat > 0.5f)
            {
                return ControllerInputPoller.instance.leftControllerGripFloat > 0.5f;
            }
            return false;
        }
        public static bool RightTrigger()
        {
            if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.5f)
            {
                return ControllerInputPoller.instance.rightControllerIndexFloat > 0.5f;
            }
            return false;
        }
        public static bool LeftTrigger()
        {
            if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.5f)
            {
                return ControllerInputPoller.instance.leftControllerIndexFloat > 0.5f;
            }
            return false;
        }
        public static bool RightB()
        {
            if (ControllerInputPoller.instance.rightControllerPrimaryButton)
            {
                return ControllerInputPoller.instance.rightControllerPrimaryButton;
            }
            return false;
        }
        public static bool LeftY()
        {
            if (ControllerInputPoller.instance.leftControllerPrimaryButton)
            {
                return ControllerInputPoller.instance.leftControllerPrimaryButton;
            }
            return false;
        }
        public static bool RightA()
        {
            if (ControllerInputPoller.instance.rightControllerSecondaryButton)
            {
                return ControllerInputPoller.instance.rightControllerSecondaryButton;
            }
            return false;
        }
        public static bool LeftX()
        {
            if (ControllerInputPoller.instance.leftControllerSecondaryButton)
            {
                return ControllerInputPoller.instance.leftControllerSecondaryButton;
            }
            return false;
        }
        public static bool LJoystick_FOWARD()
        {
            var joystick = Gamepad.current;
            if (joystick != null)
            {
                float FowardTarget = joystick.leftStick.y.ReadValue();
                if (FowardTarget > 0.5f)
                {
                    return true;
                }
            }
            return false;
        }
        public static bool LJoystick_BACKWARD()
        {
            var joystick = Gamepad.current;
            if (joystick != null)
            {
                float FowardTarget = joystick.leftStick.y.ReadValue();
                if (FowardTarget > -0.5f)
                {
                    return true;
                }
            }
            return false;
        }
        public static bool LJoystick_LEFT()
        {
            var joystick = Gamepad.current;
            if (joystick != null)
            {
                float FowardTarget = joystick.leftStick.x.ReadValue();
                if (FowardTarget > -0.5f)
                {
                    return true;
                }
            }
            return false;
        }
        public static bool LJoystick_RIGHT()
        {
            var joystick = Gamepad.current;
            if (joystick != null)
            {
                float FowardTarget = joystick.leftStick.x.ReadValue();
                if (FowardTarget > 0.5f)
                {
                    return true;
                }
            }
            return false;
        }
        public static bool RJoystick_FOWARD()
        {
            var joystick = Gamepad.current;
            if (joystick != null)
            {
                float FowardTarget = joystick.rightStick.y.ReadValue();
                if (FowardTarget > 0.5f)
                {
                    return true;
                }
            }
            return false;
        }
        public static bool RJoystick_BACKWARD()
        {
            var joystick = Gamepad.current;
            if (joystick != null)
            {
                float FowardTarget = joystick.rightStick.y.ReadValue();
                if (FowardTarget > -0.5f)
                {
                    return true;
                }
            }
            return false;
        }
        public static bool RJoystick_LEFT()
        {
            var joystick = Gamepad.current;
            if (joystick != null)
            {
                float FowardTarget = joystick.rightStick.x.ReadValue();
                if (FowardTarget > -0.5f)
                {
                    return true;
                }
            }
            return false;
        }
        public static bool RJoystick_RIGHT()
        {
            var joystick = Gamepad.current;
            if (joystick != null)
            {
                float FowardTarget = joystick.rightStick.x.ReadValue();
                if (FowardTarget > 0.5f)
                {
                    return true;
                }
            }
            return false;
        }
        public static bool MouseR()
        {
            if (UnityEngine.InputSystem.Mouse.current.rightButton.isPressed)
            {
                return UnityEngine.InputSystem.Mouse.current.rightButton.isPressed;
            }
            return false;
        }
        public static bool MouseL()
        {
            if (UnityEngine.InputSystem.Mouse.current.leftButton.isPressed)
            {
                return UnityEngine.InputSystem.Mouse.current.leftButton.isPressed;
            }
            return false;
        }
        public static bool KeyboardKey(Key Key)
        {
            if (Keyboard.current[Key].isPressed)
            {
                return true;
            }
            return false;
        }
    }
}
