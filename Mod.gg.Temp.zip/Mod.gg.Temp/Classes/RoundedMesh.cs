﻿using Mod.gg.Menu;
using Mod.gg.Patches;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using static Mod.gg.Menu.Config;

namespace Mod.gg.Classes
{
    public static class RoundedMesh
    {
        public static void MakeRounded(GameObject cube, float radius = 0.06f, int segments = 20)
        {
            if (cube == null) return;

            MeshFilter mf = cube.GetComponent<MeshFilter>();
            if (mf == null) mf = cube.AddComponent<MeshFilter>();

            MeshRenderer mr = cube.GetComponent<MeshRenderer>();
            if (mr == null) mr = cube.AddComponent<MeshRenderer>();

            Mesh mesh = GenerateRoundedCube(radius, segments);
            mf.sharedMesh = mesh;
        }
        public static void MakeRoundedButtons(GameObject cube, float radius = 0.03f, int segments = 10)
        {
            if (cube == null) return;

            MeshFilter mf = cube.GetComponent<MeshFilter>();
            if (mf == null) mf = cube.AddComponent<MeshFilter>();

            MeshRenderer mr = cube.GetComponent<MeshRenderer>();
            if (mr == null) mr = cube.AddComponent<MeshRenderer>();

            Mesh mesh = GenerateRoundedCube(radius, segments);
            mf.sharedMesh = mesh;
        }
        public static void MakeRoundedButtonsBottom(GameObject cube, float radius = 0.1f, int segments = 15)
        {
            if (cube == null) return;

            MeshFilter mf = cube.GetComponent<MeshFilter>();
            if (mf == null) mf = cube.AddComponent<MeshFilter>();

            MeshRenderer mr = cube.GetComponent<MeshRenderer>();
            if (mr == null) mr = cube.AddComponent<MeshRenderer>();

            Mesh mesh = GenerateRoundedCube(radius, segments);
            mf.sharedMesh = mesh;
        }

        private static Mesh GenerateRoundedCube(float radius, int segments)
        {
            Mesh mesh = new Mesh();
            mesh.name = "RoundedCube";

            List<Vector3> vertices = new List<Vector3>();
            List<int> triangles = new List<int>();
            List<Vector3> normals = new List<Vector3>();

            float size = 1f;
            float halfSize = size / 2f;
            float inner = halfSize - radius;
            Vector3[,,] grid = new Vector3[segments + 1, segments + 1, segments + 1];

            for (int x = 0; x <= segments; x++)
            {
                float fx = Mathf.Lerp(-halfSize, halfSize, (float)x / segments);
                for (int y = 0; y <= segments; y++)
                {
                    float fy = Mathf.Lerp(-halfSize, halfSize, (float)y / segments);
                    for (int z = 0; z <= segments; z++)
                    {
                        float fz = Mathf.Lerp(-halfSize, halfSize, (float)z / segments);

                        Vector3 point = new Vector3(fx, fy, fz);
                        Vector3 clamped = new Vector3(
                            Mathf.Clamp(fx, -inner, inner),
                            Mathf.Clamp(fy, -inner, inner),
                            Mathf.Clamp(fz, -inner, inner)
                        );

                        Vector3 offset = point - clamped;
                        float dist = offset.magnitude;

                        if (dist > 0f)
                        {
                            float t = Mathf.SmoothStep(0f, 1f, dist / radius);
                            point = clamped + offset.normalized * radius * t;
                        }

                        grid[x, y, z] = point;
                    }
                }
            }
            Dictionary<Vector3, int> vertMap = new Dictionary<Vector3, int>();

            void AddVertex(Vector3 v, Vector3 normal)
            {
                if (!vertMap.ContainsKey(v))
                {
                    vertMap[v] = vertices.Count;
                    vertices.Add(v);
                    normals.Add(normal.normalized);
                }
            }

            void AddQuad(Vector3 v00, Vector3 v01, Vector3 v11, Vector3 v10)
            {
                int i00 = vertMap[v00];
                int i01 = vertMap[v01];
                int i11 = vertMap[v11];
                int i10 = vertMap[v10];

                triangles.Add(i00); triangles.Add(i10); triangles.Add(i11);
                triangles.Add(i11); triangles.Add(i01); triangles.Add(i00);
            }

            for (int x = 0; x < segments; x++)
            {
                for (int y = 0; y < segments; y++)
                {
                    for (int z = 0; z < segments; z++)
                    {
                        Vector3 v000 = grid[x, y, z];
                        Vector3 v100 = grid[x + 1, y, z];
                        Vector3 v010 = grid[x, y + 1, z];
                        Vector3 v110 = grid[x + 1, y + 1, z];
                        Vector3 v001 = grid[x, y, z + 1];
                        Vector3 v101 = grid[x + 1, y, z + 1];
                        Vector3 v011 = grid[x, y + 1, z + 1];
                        Vector3 v111 = grid[x + 1, y + 1, z + 1];

                        AddVertex(v000, v000.normalized);
                        AddVertex(v100, v100.normalized);
                        AddVertex(v010, v010.normalized);
                        AddVertex(v110, v110.normalized);
                        AddVertex(v001, v001.normalized);
                        AddVertex(v101, v101.normalized);
                        AddVertex(v011, v011.normalized);
                        AddVertex(v111, v111.normalized);

                        AddQuad(v100, v101, v111, v110);
                        AddQuad(v000, v010, v011, v001);
                        AddQuad(v010, v110, v111, v011);
                        AddQuad(v000, v001, v101, v100);
                        AddQuad(v001, v011, v111, v101);
                        AddQuad(v000, v100, v110, v010);
                    }
                }
            }

            mesh.SetVertices(vertices);
            mesh.SetNormals(normals);
            mesh.SetTriangles(triangles, 0);
            mesh.RecalculateBounds();
            mesh.RecalculateNormals();

            return mesh;
        }

        public static void makeoutline(GameObject baseobj)
        {
            if (HasOutline)
            {
                GameObject Outline = GameObject.CreatePrimitive(PrimitiveType.Cube);
                UnityEngine.Object.Destroy(Outline.GetComponent<Rigidbody>());
                Outline.GetComponent<BoxCollider>().isTrigger = false;
                Outline.transform.parent = Main.menu.transform;
                Outline.transform.localScale = baseobj.transform.localScale + new Vector3(0f, 0.009f, 0.009f) - new Vector3(0.1f, 0f, 0f);
                Outline.transform.localPosition = baseobj.transform.localPosition;
                Outline.GetComponent<Renderer>().material.color = OutlineColor;
                UnityEngine.Object.Destroy(Outline.GetComponent<Rigidbody>());
                UnityEngine.Object.Destroy(Outline.GetComponent<BoxCollider>());
                RoundedMesh.MakeRounded(Outline);
            }
        }
        public static void makeoutlinebutton(GameObject baseobj)
        {
            if (HasOutline)
            {
                GameObject Outline = GameObject.CreatePrimitive(PrimitiveType.Cube);
                UnityEngine.Object.Destroy(Outline.GetComponent<Rigidbody>());
                Outline.GetComponent<BoxCollider>().isTrigger = false;
                Outline.transform.parent = Main.menu.transform;
                Outline.transform.localScale = baseobj.transform.localScale + new Vector3(0f, 0.009f, 0.009f) - new Vector3(0.1f, 0f, 0f);
                Outline.transform.localPosition = baseobj.transform.localPosition;
                Outline.GetComponent<Renderer>().material.color = OutlineColor;
                UnityEngine.Object.Destroy(Outline.GetComponent<Rigidbody>());
                UnityEngine.Object.Destroy(Outline.GetComponent<BoxCollider>());
                RoundedMesh.MakeRoundedButtons(Outline);
            }
        }
        public static void makeoutlinebuttonbottom(GameObject baseobj)
        {
            if (HasOutline)
            {
                GameObject Outline = GameObject.CreatePrimitive(PrimitiveType.Cube);
                UnityEngine.Object.Destroy(Outline.GetComponent<Rigidbody>());
                Outline.GetComponent<BoxCollider>().isTrigger = false;
                Outline.transform.parent = Main.menu.transform;
                Outline.transform.localScale = baseobj.transform.localScale + new Vector3(0f, 0.009f, 0.009f) - new Vector3(0.1f, 0f, 0f);
                Outline.transform.localPosition = baseobj.transform.localPosition;
                Outline.GetComponent<Renderer>().material.color = OutlineColor;
                UnityEngine.Object.Destroy(Outline.GetComponent<Rigidbody>());
                UnityEngine.Object.Destroy(Outline.GetComponent<BoxCollider>());
                RoundedMesh.MakeRoundedButtonsBottom(Outline);
            }
        }
    }
}
