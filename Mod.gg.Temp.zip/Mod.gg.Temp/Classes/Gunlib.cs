﻿using Mod.gg.Classes;
using System;
using UnityEngine;
using UnityEngine.Animations.Rigging;
using UnityEngine.InputSystem;

public class Gunlib
{
    public static RaycastHit hit;
    public static VRRig Gunlock;
    public static GameObject pointer;
    public static GameObject lineObject;
    public static LineRenderer line;
    public static bool Controller_input = true;
    public static bool pc_input = false;

    static Gunlib()
    {
        pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        UnityEngine.Object.Destroy(pointer.GetComponent<Rigidbody>());
        UnityEngine.Object.Destroy(pointer.GetComponent<SphereCollider>());
        pointer.SetActive(false);

        lineObject = new GameObject("Line");
        line = lineObject.AddComponent<LineRenderer>();
        line.startWidth = 0.02f;
        line.endWidth = 0.02f;
        line.material = new Material(Shader.Find("GUI/Text Shader")) { color = Color.gray };
        line.startColor = Color.white;
        line.endColor = Color.gray;
        line.useWorldSpace = true;
        lineObject.SetActive(false);
    }

    public static void GunLib_(Action mod, bool lockon)
    {
        if (Mouse.current.rightButton.isPressed)
        {
            pc_input = true;
            Controller_input = false;
        }
        if (Inputs.RightGrip())
        {
            pc_input = false;
            Controller_input = true;
        }

        bool VRInput = Controller_input && Inputs.RightGrip();
        bool PCInput = pc_input && Mouse.current.rightButton.isPressed;
        bool showGun = VRInput || PCInput;

        lineObject.SetActive(showGun);
        pointer.SetActive(showGun);

        if (!showGun) return;

        Ray ray = new Ray();

        if (VRInput)
        {
            Vector3 rayOrigin = GorillaLocomotion.GTPlayer.Instance.rightControllerTransform.position;
            ray = new Ray(rayOrigin, GorillaLocomotion.GTPlayer.Instance.rightControllerTransform.forward);
        }
        else if (PCInput)
        {
            ray = Camera.main.ScreenPointToRay(Mouse.current.position.ReadValue());
        }

        if (Physics.Raycast(ray, out hit))
        {
            CreateGun(hit);

            if ((VRInput && Inputs.RightTrigger()) || (PCInput && Mouse.current.leftButton.isPressed))
            {
                ModHandle(mod, lockon);
            }
        }
    }


    private static void CreateGun(RaycastHit hit)
    {
        if (line == null || pointer == null) return;

        Vector3 origin = Controller_input
            ? GorillaLocomotion.GTPlayer.Instance.rightControllerTransform.position
            : GorillaLocomotion.GTPlayer.Instance.headCollider.transform.position;

        line.SetPosition(0, origin);
        line.SetPosition(1, hit.point);

        pointer.GetComponent<Renderer>().material.color =
            (Controller_input && Inputs.RightTrigger()) || (pc_input && Mouse.current.leftButton.isPressed)
            ? Color.grey : Color.white;

        pointer.transform.position = hit.point;
        pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
        GameObject.Destroy(pointer.GetComponent<Collider>());
        GameObject.Destroy(pointer.GetComponent<Rigidbody>());
        GameObject.Destroy(line.GetComponent<Rigidbody>());
        GameObject.Destroy(line.GetComponent<Collider2D>());
    }

    private static void ModHandle(Action mod, bool lockon)
    {
        if (lockon)
        {
            VRRig personLocked = hit.rigidbody?.GetComponent<VRRig>();
            if (personLocked != null)
            {
                Gunlock = personLocked;
                mod?.Invoke();
                return;
            }
        }

        mod?.Invoke();
    }
}
