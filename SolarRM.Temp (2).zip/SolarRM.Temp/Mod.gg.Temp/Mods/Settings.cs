﻿using static Mod.gg.Menu.Main;
using static Mod.gg.Menu.Config;

namespace Mod.gg.Mods
{
    internal class SettingsMods
    {
        public static void EnterSettings()
        {
            buttonsType = 1;
        }

        public static void MenuSettings()
        {
            buttonsType = 2;
        }

        public static void MovementSettings()
        {
            buttonsType = 3;
        }

        public static void ProjectileSettings()
        {
            buttonsType = 4;
        }
        public static void EnterSaftey()
        {
            buttonsType = 5;
            pageNumber = 0;
        }
        public static void EnterMovement()
        {
            buttonsType = 6;
            pageNumber = 0;
        }
        public static void EnterVisual()
        {
            buttonsType = 7;
            pageNumber = 0;
        }
        public static void EnterPlayer()
        {
            buttonsType = 8;
            pageNumber = 0;
        }
        public static void EnterRoom()
        {
            buttonsType = 9;
            pageNumber = 0;
        }
        public static void RightHand()
        {
            RightHanded = true;
        }

        public static void LeftHand()
        {
            RightHanded = false;
        }

        public static void EnableFPSCounter()
        {
            fpsCounterEnabled = true;
        }

        public static void DisableFPSCounter()
        {
            fpsCounterEnabled = false;
        }

        public static void EnableNotifications()
        {
            DisconnectButtonEnabled = false;
        }

        public static void DisableNotifications()
        {
            disableNotifications = true;
        }

        public static void EnableDisconnectButton()
        {
            DisconnectButtonEnabled = true;
        }

        public static void DisableDisconnectButton()
        {
            DisconnectButtonEnabled = false;
        }
    }
}
