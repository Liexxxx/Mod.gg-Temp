﻿using Mod.gg.Classes;
using Mod.gg.Menu;
using System;
using UnityEngine;
using UnityEngine.InputSystem;

public static class Gunlib
{
    public static GameObject GunSphere { get; private set; }
    public static LineRenderer LineRenderer { get; private set; }
    public static GameObject Pointer { get; private set; }
    public static VRRig LockedTarget { get; private set; }
    public static RaycastHit HitInfo { get; private set; }
    private static bool controllerMode = true;
    private static bool isSphereEnabled = true;
    static Gunlib()
    {
        Pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        UnityEngine.Object.Destroy(Pointer.GetComponent<Rigidbody>());
        UnityEngine.Object.Destroy(Pointer.GetComponent<SphereCollider>());
        Pointer.SetActive(false);
    }
    public static void UpdateGun(Action modAction, bool lockOn)
    {
        if (Mouse.current.rightButton.isPressed) controllerMode = false;
        if (Inputs.RightGrip()) controllerMode = true;
        bool inputActive = controllerMode ? Inputs.RightGrip() : Mouse.current.rightButton.isPressed;
        bool shootPressed = controllerMode ? Inputs.RightTrigger() : Mouse.current.leftButton.isPressed;
        Pointer.SetActive(inputActive);
        if (!inputActive)
        {
            Cleanup();
            return;
        }
        Ray ray;
        if (controllerMode)
        {
            ray = new Ray(
                GorillaLocomotion.GTPlayer.Instance.rightControllerTransform.position,
                GorillaLocomotion.GTPlayer.Instance.rightControllerTransform.forward
            );
        }
        else
        {
            ray = GameObject.Find("Shoulder Camera").GetComponent<Camera>().ScreenPointToRay(Mouse.current.position.ReadValue());
        }

        if (Physics.Raycast(ray, out RaycastHit hit, 100f))
        {
            HitInfo = hit;
            if (GunSphere == null)
            {
                GunSphere = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                GunSphere.transform.localScale = isSphereEnabled ? Vector3.one * 0.1f : Vector3.zero;
                GunSphere.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
                GunSphere.GetComponent<Renderer>().material.color = new Color(0.025f, 0.025f, 0.025f);
                UnityEngine.Object.Destroy(GunSphere.GetComponent<Collider>());
                LineRenderer = GunSphere.AddComponent<LineRenderer>();
                LineRenderer.material = new Material(Shader.Find("Sprites/Default"));
                LineRenderer.widthCurve = AnimationCurve.Linear(0, 0.01f, 1, 0.01f);
                LineRenderer.startColor = Config.MenuColor;
                LineRenderer.endColor = Config.MenuButtonEnabledColor;
            }
            LineRenderer.SetPosition(0, GorillaLocomotion.GTPlayer.Instance.headCollider.transform.position);
            GunSphere.transform.position = hit.point;
            LineRenderer.positionCount = 25;
            for (int i = 0; i < 25; i++)
            {
                LineRenderer.SetPosition(i, Vector3.Lerp(ray.origin, hit.point, i / 24f) + UnityEngine.Random.insideUnitSphere * 0.01f);
            }
            Pointer.transform.position = hit.point;
            Pointer.transform.localScale = Vector3.one * 0.1f;
            Pointer.GetComponent<Renderer>().material.color = shootPressed ? Config.MenuButtonEnabledColor : Config.MenuColor;
            if (shootPressed)
            {
                if (lockOn)
                {
                    VRRig target = hit.rigidbody?.GetComponent<VRRig>();
                    if (target != null)
                    {
                        LockedTarget = target;
                        modAction?.Invoke();
                        return;
                    }
                }
                modAction?.Invoke();
            }
        }
        else
        {
            Cleanup();
        }
    }
    private static void Cleanup()
    {
        if (GunSphere != null)
        {
            UnityEngine.Object.Destroy(GunSphere);
            GunSphere = null;
        }
        if (LineRenderer != null)
        {
            UnityEngine.Object.Destroy(LineRenderer);
            LineRenderer = null;
        }
        if (Pointer != null) Pointer.SetActive(false);
    }
}
