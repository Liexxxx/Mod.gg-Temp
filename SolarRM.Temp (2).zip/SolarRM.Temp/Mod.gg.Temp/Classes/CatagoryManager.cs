﻿using Mod.gg.Menu;
using Mod.gg.Mods;
using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Text;
using static Mod.gg.Menu.Config;

namespace Mod.gg.Classes
{
    class CatagoryManager
    {
        public static void OpenCatagory(MainCategory mainCategory)
        {
            if (mainCategory == MainCategory.Settings)
            {
                SettingsMods.EnterSettings();
            }
            if (mainCategory == MainCategory.Safety)
            {
                SettingsMods.EnterSaftey();
            }
            if (mainCategory == MainCategory.Movement)
            {
                SettingsMods.EnterMovement();
            }
            if (mainCategory == MainCategory.Visual)
            {
                SettingsMods.EnterVisual();
            }
            if (mainCategory == MainCategory.Player)
            {
                SettingsMods.EnterPlayer();
            }
            if (mainCategory == MainCategory.Room)
            {
                SettingsMods.EnterRoom();
            }
        }
        public static ButtonInfo BtnCatagory_Search(Config.Category category,string BtnText)
        {
            foreach (ButtonInfo[] buttons in Menu.Buttons.buttons)
            {
                foreach (ButtonInfo button in buttons)
                {
                    if (button.ButtonCategory == category && button.buttonText == BtnText)
                    {
                        return button;
                    }
                }
            }
            return null;
        }
    }
}
