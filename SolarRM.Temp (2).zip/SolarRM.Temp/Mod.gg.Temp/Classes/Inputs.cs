﻿using System;
using UnityEngine;
using UnityEngine.InputSystem;

namespace Mod.gg.Classes
{
    internal class Inputs
    {
        private static bool IsButtonPressed(float inputValue, float Value = 0.5f)
        {
            return inputValue > Value;
        }
        private static bool IsJoystickMoved(float inputValue, float Value = 0.5f)
        {
            return Mathf.Abs(inputValue) > Value;
        }
        public static bool RightGrip() => IsButtonPressed(ControllerInputPoller.instance.rightControllerGripFloat);
        public static bool LeftGrip() => IsButtonPressed(ControllerInputPoller.instance.leftControllerGripFloat);
        public static bool RightTrigger() => IsButtonPressed(ControllerInputPoller.instance.rightControllerIndexFloat);
        public static bool LeftTrigger() => IsButtonPressed(ControllerInputPoller.instance.leftControllerIndexFloat);
        public static bool RightX() => ControllerInputPoller.instance.rightControllerPrimaryButton;
        public static bool LeftA() => ControllerInputPoller.instance.leftControllerPrimaryButton;
        public static bool RightY() => ControllerInputPoller.instance.rightControllerSecondaryButton;
        public static bool LeftB() => ControllerInputPoller.instance.leftControllerSecondaryButton;
        public static bool LJoystick_FOWARD() => IsJoystickMoved(Gamepad.current?.leftStick.y.ReadValue() ?? 0f);
        public static bool LJoystick_BACKWARD() => IsJoystickMoved(Gamepad.current?.leftStick.y.ReadValue() ?? 0f, -0.5f);
        public static bool LJoystick_LEFT() => IsJoystickMoved(Gamepad.current?.leftStick.x.ReadValue() ?? 0f, -0.5f);
        public static bool LJoystick_RIGHT() => IsJoystickMoved(Gamepad.current?.leftStick.x.ReadValue() ?? 0f);
        public static bool RJoystick_FOWARD() => IsJoystickMoved(Gamepad.current?.rightStick.y.ReadValue() ?? 0f);
        public static bool RJoystick_BACKWARD() => IsJoystickMoved(Gamepad.current?.rightStick.y.ReadValue() ?? 0f, -0.5f);
        public static bool RJoystick_LEFT() => IsJoystickMoved(Gamepad.current?.rightStick.x.ReadValue() ?? 0f, -0.5f);
        public static bool RJoystick_RIGHT() => IsJoystickMoved(Gamepad.current?.rightStick.x.ReadValue() ?? 0f);
        public static bool MouseR() => UnityEngine.InputSystem.Mouse.current.rightButton.isPressed;
        public static bool MouseL() => UnityEngine.InputSystem.Mouse.current.leftButton.isPressed;
        public static bool KeyboardKey(Key key) => Keyboard.current[key].isPressed;
    }
}
