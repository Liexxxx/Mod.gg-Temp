﻿using Constants;
using ExitGames.Client.Photon.StructWrapping;
using GorillaNetworking;
using Photon.Pun;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using UnityEngine;

namespace Mod.gg.Classes
{
    class SafteyManager
    {
        public static void NoGameQuitTrace()
        {
            if (ApplicationQuittingState.IsQuitting)
            {
                PhotonNetworkController.Instance.OnApplicationQuit();
                PhotonNetwork.OpCleanActorRpcBuffer(PhotonNetwork.LocalPlayer.ActorNumber);
                PhotonNetwork.OpCleanRpcBuffer(PhotonNetwork.LocalPlayer.Get<PhotonView>());
                PhotonNetwork.OpCleanRpcBuffer(GorillaTagger.Instance.offlineVRRig.Get<VRRig>().Creator.Get<PhotonView>());
                PhotonNetwork.OpRemoveCompleteCache();
                PhotonNetwork.OpRemoveCompleteCacheOfPlayer(PhotonNetwork.LocalPlayer.ActorNumber);
                PhotonNetwork.NetworkingClient.RemoveCallbackTarget(PhotonNetworkController.Instance);
                PhotonNetwork.NetworkingClient.RemoveCallbackTarget(GorillaTagger.Instance);
                GorillaTagger.Instance?.Destroy();
                PhotonNetworkController.Instance?.Destroy();
                PhotonNetwork.RemoveRPCs(PhotonNetwork.LocalPlayer);
                Resources.UnloadUnusedAssets();
                PhotonNetwork.LocalPlayer.CustomProperties = null;
                PhotonNetwork.LocalPlayer.SetCustomProperties(new ExitGames.Client.Photon.Hashtable());
                PhotonNetwork.Disconnect();
                while (PhotonNetwork.IsConnected)
                {
                    Thread.Sleep(10);
                }
                GorillaTagger.Instance?.Destroy();
                PhotonNetworkController.Instance?.Destroy();
                PhotonNetwork.LocalCleanPhotonView(VRRig.LocalRig.GetComponent<PhotonView>());
                System.GC.Collect();
                System.GC.WaitForPendingFinalizers();
                System.GC.Collect();
            }
        }
        public static void FlushRPC()
        {
            PhotonNetwork.OpCleanActorRpcBuffer(PhotonNetwork.LocalPlayer.ActorNumber);
            PhotonNetwork.OpCleanRpcBuffer(PhotonNetwork.LocalPlayer.Get<PhotonView>());
            PhotonNetwork.OpCleanRpcBuffer(GorillaTagger.Instance.offlineVRRig.Get<VRRig>().Creator.Get<PhotonView>());
            PhotonNetwork.OpRemoveCompleteCache();
            PhotonNetwork.OpRemoveCompleteCacheOfPlayer(PhotonNetwork.LocalPlayer.ActorNumber);
            PhotonNetwork.OpRemoveCompleteCacheOfPlayer(PhotonNetwork.LocalPlayer.ActorNumber);
            PhotonNetwork.OpCleanRpcBuffer(PhotonNetwork.GetPhotonView(1));
        }
        private static float timeElapsed = 0f;
        private static float flushInterval = 60f;
        public static void AutoFlushRPCS()
        {
            timeElapsed += Time.deltaTime;

            if (timeElapsed >= flushInterval)
            {
                PhotonNetwork.OpCleanActorRpcBuffer(PhotonNetwork.LocalPlayer.ActorNumber);
                PhotonNetwork.OpCleanRpcBuffer(PhotonNetwork.LocalPlayer.Get<PhotonView>());
                PhotonNetwork.OpCleanRpcBuffer(GorillaTagger.Instance.offlineVRRig.Get<VRRig>().Creator.Get<PhotonView>());
                PhotonNetwork.OpRemoveCompleteCache();
                PhotonNetwork.OpRemoveCompleteCacheOfPlayer(PhotonNetwork.LocalPlayer.ActorNumber);
                PhotonNetwork.OpRemoveCompleteCacheOfPlayer(PhotonNetwork.LocalPlayer.ActorNumber);
                PhotonNetwork.OpCleanRpcBuffer(PhotonNetwork.GetPhotonView(1));
                timeElapsed = 0f; 
            }
        }
    }
}
