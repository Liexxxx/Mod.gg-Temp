﻿using Photon.Realtime;
using Photon.Pun;
using BepInEx;
using HarmonyLib;
using UnityEngine;
using System.Linq;

namespace Mod.gg.Classes
{
    internal class RigManager : BaseUnityPlugin
    {
        public static VRRig GetVRRigFromPlayer(Player player)
        {
            return GorillaGameManager.instance.FindPlayerVRRig(player);
        }

        public static VRRig GetRandomVRRig(bool includeSelf)
        {
            VRRig randomRig = GorillaParent.instance.vrrigs[UnityEngine.Random.Range(0, GorillaParent.instance.vrrigs.Count)];

            if (includeSelf || randomRig != GorillaTagger.Instance.offlineVRRig)
            {
                return randomRig;
            }

            return GetRandomVRRig(includeSelf);
        }

        public static VRRig GetClosestVRRig()
        {
            float minDistance = float.MaxValue;
            VRRig closestRig = null;
            Vector3 playerPosition = GorillaTagger.Instance.bodyCollider.transform.position;

            foreach (VRRig rig in GorillaParent.instance.vrrigs)
            {
                float distance = Vector3.Distance(playerPosition, rig.transform.position);
                if (distance < minDistance)
                {
                    minDistance = distance;
                    closestRig = rig;
                }
            }

            return closestRig;
        }

        public static PhotonView GetPhotonViewFromVRRig(VRRig rig)
        {
            return Traverse.Create(rig).Field("photonView").GetValue<PhotonView>();
        }

        public static Player GetRandomPlayer(bool includeSelf)
        {
            Player[] playerList = includeSelf ? PhotonNetwork.PlayerList : PhotonNetwork.PlayerListOthers;

            if (playerList.Length > 0)
            {
                return playerList[UnityEngine.Random.Range(0, playerList.Length)];
            }
            return null;
        }

        public static Player GetPlayerFromVRRig(VRRig rig)
        {
            PhotonView photonView = GetPhotonViewFromVRRig(rig);
            return photonView ? photonView.Owner : null;
        }

        public static Player GetPlayerFromID(string userId)
        {
            return PhotonNetwork.PlayerList.FirstOrDefault(player => player.UserId == userId);
        }

        public static Player[] GetAllPlayers()
        {
            return PhotonNetwork.PlayerList;
        }

        public static Player[] GetAllOtherPlayers()
        {
            return PhotonNetwork.PlayerListOthers;
        }

        public static bool IsPlayerInGame(Player player)
        {
            return PhotonNetwork.PlayerList.Contains(player);
        }

        public static VRRig[] GetVRRigsInRange(float range)
        {
            Vector3 playerPosition = GorillaTagger.Instance.bodyCollider.transform.position;

            return GorillaParent.instance.vrrigs
                .Where(rig => Vector3.Distance(playerPosition, rig.transform.position) <= range)
                .ToArray();
        }

        public static float GetAverageDistanceFromPlayer()
        {
            Vector3 playerPosition = GorillaTagger.Instance.bodyCollider.transform.position;
            float totalDistance = 0f;
            int rigCount = GorillaParent.instance.vrrigs.Count;

            if (rigCount == 0)
                return 0;

            foreach (VRRig rig in GorillaParent.instance.vrrigs)
            {
                totalDistance += Vector3.Distance(playerPosition, rig.transform.position);
            }

            return totalDistance / rigCount;
        }

        public static Player GetClosestPlayer()
        {
            float minDistance = float.MaxValue;
            Player closestPlayer = null;
            Vector3 playerPosition = GorillaTagger.Instance.bodyCollider.transform.position;

            foreach (Player player in PhotonNetwork.PlayerList)
            {
                if (player.IsLocal)
                    continue;

                VRRig playerRig = GetVRRigFromPlayer(player);
                if (playerRig != null)
                {
                    float distance = Vector3.Distance(playerPosition, playerRig.transform.position);
                    if (distance < minDistance)
                    {
                        minDistance = distance;
                        closestPlayer = player;
                    }
                }
            }

            return closestPlayer;
        }
    }
}
